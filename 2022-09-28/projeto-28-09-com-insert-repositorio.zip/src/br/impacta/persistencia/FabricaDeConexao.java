package br.impacta.persistencia;

import java.sql.Connection;
import java.sql.DriverManager;

public class FabricaDeConexao {

	private static String USERNAME = "root";
	private static String PASSWORD = "A50kl63b@";
	
	
	private static String DATABASE_URL = "jdbc:mysql://localhost:3306/banco_rh?useTimezone=true&serverTimezone=UTC";
	
	public static Connection criarConexaoMySql()  throws Exception {
		
		Class.forName("com.mysql.cj.jdbc.Driver"); //Indica qual o Jar que será utilizado para identificar a conexão entre Java e o MySql
		
		
		Connection conexao = DriverManager.getConnection(DATABASE_URL, USERNAME, PASSWORD);
		
		return conexao;
	}
	
	
	
}
