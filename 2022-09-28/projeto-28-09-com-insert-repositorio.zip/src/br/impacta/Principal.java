package br.impacta;

import br.impacta.controlador.ControleDeCadastro;

public class Principal {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

		ControleDeCadastro controleDeCadastro = new ControleDeCadastro();
		controleDeCadastro.iniciarPrograma();
		
	/*	FabricaDeConexao fabricaConexao = new FabricaDeConexao();
		Connection connectionTeste = fabricaConexao.criarConexaoMySql();
		
		if(!((connectionTeste) == null)) {
			
			System.out.println("Conectado");
		}else {
			System.out.println("Não conectado");
		}
		*/
	}

}
