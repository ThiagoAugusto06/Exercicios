package br.impacta.telas;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import br.impacta.model.Gerente;
import br.impacta.repositorio.RepositorioGerente;
import br.impacta.telas.controletelas.FormGerenteDetalheControle;

public class FormGerenteDetalhe {

	
public void detalheGerente(JFrame telaInicial, RepositorioGerente repositorioGerente, Gerente gerenteAtual) {
		
		String nomeGerente = "Nome do Gerente: ";
		String cpfGerente = "CPF do Gerente: ";
		String salarioGerente = "Salario do Gerente: ";
		String regionalGerente = "Regional do Gerente: ";
		String enderecoGerente = "Endereço do Gerente:";
		String bairroGerente = "Bairro do Gerente:";
		
		//Detalhes do Formulário (Frame)
		JFrame frameFormGerenteDetalhe = new JFrame();
		frameFormGerenteDetalhe.setSize(200, 300);
		frameFormGerenteDetalhe.setTitle("Alteração de Gerentes - Versão 26-09");
		frameFormGerenteDetalhe.setLocation(300,300);
		
		JPanel molduraGerenteAlterar = new JPanel();
		
		JLabel lblNome = new JLabel(nomeGerente);
		molduraGerenteAlterar.add(lblNome);
		
		JTextField txtNome = new JTextField(10);
		txtNome.setText(gerenteAtual.getStrNome());
		molduraGerenteAlterar.add(txtNome);
		
		JLabel lblCpf = new JLabel(cpfGerente);
		molduraGerenteAlterar.add(lblCpf);
		
		JTextField txtCpf = new JTextField(10);
		txtCpf.setText(gerenteAtual.getStrCpf());
		txtCpf.setEnabled(false); //Quando alteração, não podemos editar o CPF
		molduraGerenteAlterar.add(txtCpf);
		
		JLabel lblSalario = new JLabel(salarioGerente);
		molduraGerenteAlterar.add(lblSalario);
		
		JTextField txtSalario = new JTextField(10);
		txtSalario.setText(Double.toString(gerenteAtual.getDblSalario()));
		molduraGerenteAlterar.add(txtSalario);

		JLabel lblRegional = new JLabel(regionalGerente);
		molduraGerenteAlterar.add(lblRegional);
		
		JTextField txtRegional = new JTextField(10);
		txtRegional.setText(gerenteAtual.getStrRegional());
		molduraGerenteAlterar.add(txtRegional);
		
		JLabel lblEndereco = new JLabel(enderecoGerente);
		molduraGerenteAlterar.add(lblEndereco);
		
		JTextField txtEndereco = new JTextField(10);
		txtEndereco.setText(gerenteAtual.getEnderecoGerente().getEndereco());
		molduraGerenteAlterar.add(txtEndereco);
		
		JLabel lblBairro = new JLabel(bairroGerente);
		molduraGerenteAlterar.add(lblBairro);
		
		JTextField txtBairro = new JTextField(10);
		txtBairro.setText(gerenteAtual.getEnderecoGerente().getBairro());
		molduraGerenteAlterar.add(txtBairro);
		
		JButton cmdAlterar = new JButton("Alterar");
		molduraGerenteAlterar.add(cmdAlterar);
		
		
		
		frameFormGerenteDetalhe.add(molduraGerenteAlterar);
		
		frameFormGerenteDetalhe.setVisible(true);
		
		FormGerenteDetalheControle formGerenteControle = new FormGerenteDetalheControle(telaInicial, frameFormGerenteDetalhe, txtNome, txtCpf, txtSalario, txtRegional, repositorioGerente, gerenteAtual, txtEndereco, txtBairro);
		cmdAlterar.addActionListener(formGerenteControle);
		
	}
	
	
	
	
	
	
	
}
