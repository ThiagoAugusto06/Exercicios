package br.impacta.telas.controletelas;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;

public class FormGerenteListarControle implements ActionListener {

	JFrame telaInicial;
	JFrame formGerenteListar;
	
	
	public FormGerenteListarControle(JFrame telaInicial, JFrame formGerenteListar) {
		super();
		this.telaInicial = telaInicial;
		this.formGerenteListar = formGerenteListar;
	}


	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		clicarMenu();
	}
	
	
	public void clicarMenu() {
		formGerenteListar.setVisible(false);
		telaInicial.setVisible(true);		
	}
	
}
