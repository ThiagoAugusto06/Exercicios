package br.impacta.telas.controletelas;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import br.impacta.model.EnderecoGerente;
import br.impacta.model.Gerente;
import br.impacta.repositorio.RepositorioGerente;
import br.impacta.telas.validacao.ValidaGerente;

public class FormGerenteControle implements ActionListener{

	JFrame frameFormGerente;
	JFrame telaInicial;
	
	JTextField txtCpf;
	JTextField txtNome;
	JTextField txtSalario;
	JTextField txtRegional;
	
	JTextField txtEndereco;
	JTextField txtBairro;
	
	RepositorioGerente repositorioGerente;
	
	boolean validarSalvar = false;
	
	ValidaGerente validaGerente = new ValidaGerente();
	String strMensagemErro = null;
	
	
	//Sobrecarga - Métodos com o mesmo nome, porém, com assinaturas diferentes (Parâmetros)
	public FormGerenteControle(JFrame frameFormGerente, JFrame telaInicial, JTextField txtCpf, JTextField txtNome,	JTextField txtSalario, JTextField txtRegional, RepositorioGerente repositorioGerente, JTextField txtEndereco, JTextField txtBairro) {
		super();
		this.frameFormGerente = frameFormGerente;
		this.telaInicial = telaInicial;
		this.txtCpf = txtCpf;
		this.txtNome = txtNome;
		this.txtSalario = txtSalario;
		this.txtRegional = txtRegional;
		this.repositorioGerente = repositorioGerente;	
		this.txtEndereco = txtEndereco;
		this.txtBairro = txtBairro;
		
	}

	public FormGerenteControle() {
		
	}
	
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// Ao clicar no botão, será chamado o método eventoClicarIncluir()
		eventoClicarIncluir();
	}
	
	private void eventoClicarIncluir() {
		
		Gerente gerente = new Gerente();
		
		EnderecoGerente endereco = new EnderecoGerente();
		
		gerente.setStrNome(txtNome.getText());
		gerente.setStrCpf(txtCpf.getText());

		if(txtSalario.getText().equals("")) { //Se não digitar salário, setar 0
			txtSalario.setText("0");
		}		
		
		gerente.setDblSalario(Double.parseDouble(txtSalario.getText()));
		gerente.setStrRegional(txtRegional.getText());
		
		endereco.setEndereco(txtEndereco.getText());
		endereco.setBairro(txtBairro.getText());
		
		gerente.setEnderecoGerente(endereco);
		
		
		strMensagemErro = validaGerente.validarGerente(gerente, repositorioGerente, "I");
		
		if (strMensagemErro == null) {
		
			validarSalvar = repositorioGerente.salvarGerente(gerente);
			
			if(validarSalvar) {
				JOptionPane.showMessageDialog(frameFormGerente, gerente.getStrNome() + " incluído com sucesso.");
				telaInicial.setVisible(true);
				frameFormGerente.setVisible(false); 
			}else {
				JOptionPane.showMessageDialog(frameFormGerente, gerente.getStrNome() + " não foi incluído. Verificar parâmetros");
			}
		}else {
			JOptionPane.showMessageDialog(frameFormGerente, strMensagemErro);	
		}
		
	}
}

