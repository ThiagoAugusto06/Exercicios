package br.impacta.telas.validacao;

import br.impacta.model.Gerente;
import br.impacta.repositorio.RepositorioGerente;

public class ValidaGerente {

	public String validarGerente(Gerente gerente, RepositorioGerente repositorioGerente, String operacao) {
		
		String strMensagemErro = null;
		
		if(gerente.getStrNome().length() < 1) {
			
			strMensagemErro = "Campo de preenchimento obrigatório: Nome.";
			return strMensagemErro;
			
		} 
		
		if(gerente.getStrCpf().length() < 1) {
			
			strMensagemErro = "Campo de preenchimento obrigatório: CPF.";
			return strMensagemErro;
			
		} 
		
		//Se encontrar um CPF no repositório, exibir a mensagem de que já existe no repositório
		if (operacao.equals("I")) {
			if(repositorioGerente.obterGerente(gerente.getStrCpf()) != null) {
				
				strMensagemErro = "CPF já existente.";
				return strMensagemErro;
				
			}
		}
		
		
	
		if(gerente.getStrRegional().length() < 1) {
			
			strMensagemErro = "Campo de preenchimento obrigatório: Regional.";
			return strMensagemErro;
			
		}
		

		if(gerente.getEnderecoGerente().getEndereco().length() < 1) {
			
			strMensagemErro = "Campo de preenchimento obrigatório: Endereço.";
			return strMensagemErro;
			
		} 
		
		if(gerente.getEnderecoGerente().getBairro().length() < 1) {
			
			strMensagemErro = "Campo de preenchimento obrigatório: Bairro.";
			return strMensagemErro;
			
		} 

		return strMensagemErro;
	}
	
}
