package br.impacta.persistencia;

import java.sql.Connection;
import java.sql.DriverManager;

public class FabricaDeConexao {

	private static String Username = "root";
	private static String Password = "A50kl63b@";
	
	
	private static String Database_URL = "jdbc:mysql://localhost:3306/banco_rh";
	
	public static Connection criarConexaoMySql()  throws Exception {
		
		Class.forName("con.mysql.cj.jdbc.Driver"); //Indica qual o Jar que será utilizado para identificar a conexão entre Java e o MySql
		
		
		Connection conexao = DriverManager.getConnection(Database_URL, Username, Password);
		
		return conexao;
	}
	
	
	
}
