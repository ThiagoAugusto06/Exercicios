package br.impacta.persistencia;

import java.sql.Connection;
import java.sql.PreparedStatement;

import br.impacta.model.Gerente;

public class GerenteDao {

	public boolean incluirRegistroBanco(Gerente gerente) {
		
		boolean salvou = false;
		
		String strSql = "INSERT INTO Gerente() VALUES(?,?,?,?,?,?)";
		
		Connection conexao = null;
		
		PreparedStatement pstm = null; //objeto para a criação da consulta
		
		try {
				conexao = FabricaDeConexao.criarConexaoMySql();
				pstm = (PreparedStatement)conexao.prepareStatement(strSql); //Referência ao AdoRS
			
				pstm.setString(1, gerente.getStrCpf());
				pstm.setString(2, gerente.getStrNome());
				pstm.setString(3, Double.toString(gerente.getDblSalario()));
				pstm.setString(4, gerente.getStrRegional());
				pstm.setString(5, gerente.getEnderecoGerente().getEndereco());
				pstm.setString(6, gerente.getEnderecoGerente().getBairro());
		
				pstm.execute();
				
				salvou = true;
				
		}catch (Exception e) {
			
			e.printStackTrace();
			System.out.println("Erro ao incluir o Gerente no banco de dados");
		}finally { //Sempre é executado, com ou sem erros, este trecho sempre vai executar
			try {
				if(pstm != null) {
					pstm.close();
				}

				if(conexao != null) {
					conexao.close();
				}

			}catch (Exception e2){
				e2.printStackTrace();
				System.out.println("Erro ao realizar o fechamento da conexão com o banco de dados");				
			}
			
		}
		
		
		return salvou;
		
	}
	
	
	
}
