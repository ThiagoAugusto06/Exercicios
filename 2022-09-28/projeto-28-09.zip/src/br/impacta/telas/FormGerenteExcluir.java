package br.impacta.telas;

import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;

import br.impacta.model.Gerente;
import br.impacta.repositorio.RepositorioGerente;
import br.impacta.telas.controletelas.FormGerenteExcluirControle;

public class FormGerenteExcluir {

public void excluirGerente(List<Gerente> listaDeGerentes, JFrame telaInicial, RepositorioGerente repositorioGerente) {
		
		int vTotalLinhas = listaDeGerentes.size(); //Obter o total de linhas da lista
		
		String [][] gridGerentes = new String [vTotalLinhas][4];
		
		int vPosLin = 0;
		
		//Elaborar o Loop contendo os dados da lista montando conforme Array Bidimensional
		
		for(Gerente gerente: listaDeGerentes) {
			
			gridGerentes[vPosLin][0] = gerente.getStrCpf();
			gridGerentes[vPosLin][1] = gerente.getStrNome();
			gridGerentes[vPosLin][2] = Double.toString(gerente.getDblSalario());
			gridGerentes[vPosLin][3] = gerente.getStrRegional();
			
			vPosLin++;
		}
		
		//Criando o título para a gridGerentes
		String nomeColunas[] = {"CPF do Gerente","Nome do Gerente", "Salário do Gerente", "Reginal do Gerente" };
		
		JFrame formGerenteExcluir = new JFrame();
		formGerenteExcluir.setSize(500, 600);
		formGerenteExcluir.setTitle("Excluir Gerentes");
		
		JTable tabelaGerentes = new JTable(gridGerentes, nomeColunas);
		tabelaGerentes.setBounds(30, 140, 200, 300);
		
		JScrollPane barraDeRolagem = new JScrollPane(tabelaGerentes);
		JPanel painelGerentes = new JPanel();

		JLabel lblCpf = new JLabel("Digite o CPF para Excluir: ");
		painelGerentes.add(lblCpf);
		
		JTextField txtCpf = new JTextField(10);
		painelGerentes.add(txtCpf);
		
		JButton cmdExcluir = new JButton("Excluir");
		painelGerentes.add(cmdExcluir);
		
		painelGerentes.add(barraDeRolagem);
		
		formGerenteExcluir.add(painelGerentes);
		formGerenteExcluir.setVisible(true);
		
		
		//Realizar operação de excluir
		
		FormGerenteExcluirControle formGerenteExcluirControle = new FormGerenteExcluirControle(formGerenteExcluir, telaInicial, txtCpf, repositorioGerente);
		cmdExcluir.addActionListener(formGerenteExcluirControle);
	}
	
	
	
	
}
