package br.impacta.controlador;

import br.impacta.telas.MenuInicial;

public class ControleDeCadastro {

	public void iniciarPrograma() {

		MenuInicial menuInicial = new MenuInicial();
		menuInicial.apresentarMenuInicial();
		
	}
	
	
	
}
