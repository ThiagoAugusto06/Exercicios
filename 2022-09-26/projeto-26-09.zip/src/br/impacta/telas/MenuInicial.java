package br.impacta.telas;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import br.impacta.telas.controletelas.MenuInicialControle;

public class MenuInicial {

	public void apresentarMenuInicial() {
		
		
		
		String menuInicialTexto = "Menu Inicial";
		String opcaoUm = "(1) - Cadastrar Gerente";
		String opcaoDois = "(2) - Exibir Gerentes";
		String opcaoTres = "(3) - Excluir Gerentes";
		String opcaoQuatro = "(4) - Exibir folha de pagamento de Gerentes";
		String opcaoCinco = "(5) - Alterar Gerentes";
		String opcaoSeis = "(6) - Encerrar";
		
		//Construindo a tela
		JFrame telaInicial = new JFrame();
		telaInicial.setSize(300, 300);
		telaInicial.setTitle("Cadastro de Gerentes e Coordenadores");
		telaInicial.setLocation(300, 300);
		
		JPanel molduraTela = new JPanel();
		JLabel lblTitulo = new JLabel(menuInicialTexto);
		molduraTela.add(lblTitulo);
		
		JLabel lblOpcaoUm = new JLabel(opcaoUm);
		molduraTela.add(lblOpcaoUm);
		
		JLabel lblOpcaoDois = new JLabel(opcaoDois);
		molduraTela.add(lblOpcaoDois);
		
		JLabel lblOpcaoTres = new JLabel(opcaoTres);
		molduraTela.add(lblOpcaoTres);
		
		JLabel lblOpcaoQuatro = new JLabel(opcaoQuatro);
		molduraTela.add(lblOpcaoQuatro);
		
		JLabel lblOpcaoCinco = new JLabel(opcaoCinco);
		molduraTela.add(lblOpcaoCinco);
		
		JLabel lblOpcaoSeis = new JLabel(opcaoSeis);
		molduraTela.add(lblOpcaoSeis);
		
		
		JTextField txtOpcao = new JTextField(10);
		molduraTela.add(txtOpcao);
		
		JButton cmdBotao = new JButton("Selecionar");
		molduraTela.add(cmdBotao);
		
		telaInicial.add(molduraTela);
		
		telaInicial.setVisible(true);
		
		MenuInicialControle menuInicialControle = new MenuInicialControle(txtOpcao, telaInicial);
		cmdBotao.addActionListener(menuInicialControle);
		
	}
	
	
}
