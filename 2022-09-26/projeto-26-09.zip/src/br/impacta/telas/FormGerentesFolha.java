package br.impacta.telas;

import java.util.List;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import br.impacta.model.Gerente;

public class FormGerentesFolha {
	

	public void listarFolhaGerente(List<Gerente> listaDeGerentes, JFrame telaInicial) {
		
		int vTotalLinhas = listaDeGerentes.size(); //Obter o total de linhas da lista
		
		String [][] gridGerentes = new String [vTotalLinhas][6];
		Double dblValorINSS;
		Double dblValorIR;
		Double dblValorLiquido;
		
		int vPosLin = 0;
		
		//Elaborar o Loop contendo os dados da lista montando conforme Array Bidimensional
		
		for(Gerente gerente: listaDeGerentes) {
			
			
			
			if ((gerente.getDblSalario() * 0.15) >= 828.38) {
				dblValorINSS = 828.38;
			}else {
				dblValorINSS = gerente.getDblSalario() * 0.11;				
			}
			
			dblValorIR = gerente.getDblSalario() * 0.15;
			dblValorLiquido = gerente.getDblSalario() - dblValorINSS - dblValorIR;
			
			gridGerentes[vPosLin][0] = gerente.getStrCpf();
			gridGerentes[vPosLin][1] = gerente.getStrNome();
			gridGerentes[vPosLin][2] = Double.toString(gerente.getDblSalario());
			gridGerentes[vPosLin][3] = Double.toString(dblValorINSS);
			gridGerentes[vPosLin][4] = Double.toString(dblValorIR);
			gridGerentes[vPosLin][5] = Double.toString(dblValorLiquido);
			
			vPosLin++;
		}
		
		//Criando o título para a gridGerentes
		String nomeColunas[] = {"CPF do Gerente","Nome do Gerente", "Salário Bruto", "Desconto INSS", "Desconto IR", "Valor Líquido" };
		
		JFrame formGerenteListarFolha = new JFrame();
		formGerenteListarFolha.setSize(700, 600);
		formGerenteListarFolha.setTitle("Folha de Pagamento dos Gerentes");
		
		JTable tabelaGerentesFolha = new JTable(gridGerentes, nomeColunas);
		tabelaGerentesFolha.setBounds(30, 40, 600, 500);
		
		JScrollPane barraDeRolagemFolha = new JScrollPane(tabelaGerentesFolha);
		JPanel painelGerentesFolha = new JPanel();
		
		painelGerentesFolha.add(barraDeRolagemFolha);
		
		formGerenteListarFolha.add(painelGerentesFolha);
		formGerenteListarFolha.setVisible(true);
	
	
	
	}
}