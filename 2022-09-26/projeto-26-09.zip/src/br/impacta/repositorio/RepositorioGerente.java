package br.impacta.repositorio;

import java.util.ArrayList;
import java.util.List;

import br.impacta.model.Gerente;

public class RepositorioGerente implements IntRepositorioGerente{

	List<Gerente> listaDeGerentes = new ArrayList<>();
	
	@Override
	public boolean salvarGerente(Gerente gerente) {
		// TODO Auto-generated method stub
		try {
			listaDeGerentes.add(gerente);
			
		}catch(Exception e){
			System.out.println("Ocorreu um erro ao incluir o Gerente. Erro:" + e );
			return false;
		}
		
		
		return true;
	}

	
	public boolean excluirGerente(String cpf) {
		
		//Procurar na lista de gerentes, o CPF pesquisado. Se igual, excluir
		for(Gerente gerente: listaDeGerentes) {
			if(gerente.getStrCpf().equals(cpf)) {
				listaDeGerentes.remove(gerente);				
				return true;
			}
		}		
		return false;		
	}
	
	@Override
	public List<Gerente> exibirGerentes() {
		// TODO Auto-generated method stub
		return listaDeGerentes;
	}

	
	@Override
	public Gerente obterGerente(String cpf) {
		
		for(Gerente gerente: listaDeGerentes) {
			if(gerente.getStrCpf().equals(cpf)) {
				return gerente;
			}
			
		}
		
		return null;
	}
	
		
	@Override
	public boolean alterarGerente(Gerente gerenteAtual, Gerente gerenteNovo) {
		
		for(Gerente gerente: listaDeGerentes) {
			if(gerente == gerenteAtual) {
				listaDeGerentes.remove(gerenteAtual);
				listaDeGerentes.add(gerenteNovo);
				return true;
				
			}

		}
		
		return false;
	}
}
