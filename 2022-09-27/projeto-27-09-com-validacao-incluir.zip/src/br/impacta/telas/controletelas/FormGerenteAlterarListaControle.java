package br.impacta.telas.controletelas;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JTextField;

import br.impacta.model.Gerente;
import br.impacta.repositorio.RepositorioGerente;
import br.impacta.telas.FormGerenteDetalhe;

public class FormGerenteAlterarListaControle implements ActionListener {

	
	JFrame frameGerenteListar;
	JFrame telaInicial;
	JTextField txtCpf;
	
	RepositorioGerente repositorioGerente;

	FormGerenteDetalhe formGerenteDetalhe = new FormGerenteDetalhe();

	public FormGerenteAlterarListaControle(JFrame frameGerenteListar, JFrame telaInicial, JTextField txtCpf,
			RepositorioGerente repositorioGerente) {
		super();
		this.frameGerenteListar = frameGerenteListar;
		this.telaInicial = telaInicial;
		this.txtCpf = txtCpf;
		this.repositorioGerente = repositorioGerente;
	}




	
	@Override
	public void actionPerformed(ActionEvent e) {

		//FormGerenteDetalhe frameGerenteDetalhe = new FormGerenteDetalhe();
		//frameGerenteDetalhe.detalheGerente(txtCpf, menuInicial, frameGerenteDetalhe, repositorioGerente);
		
		Gerente gerenteAtual = new Gerente();
		
		gerenteAtual = repositorioGerente.obterGerente(txtCpf.getText());
		
		if (!(gerenteAtual == null)) {
			frameGerenteListar.setVisible(false);
			formGerenteDetalhe.detalheGerente(telaInicial, repositorioGerente, gerenteAtual);
		}

		
	}

	
}
