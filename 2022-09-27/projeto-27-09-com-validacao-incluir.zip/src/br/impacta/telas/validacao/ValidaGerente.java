package br.impacta.telas.validacao;

import br.impacta.model.Gerente;
import br.impacta.repositorio.RepositorioGerente;

public class ValidaGerente {

	public String validarGerente(Gerente gerente, RepositorioGerente repositorioGerente) {
		
		String strMensagemErro = null;
		
		//Se encontrar um CPF no repositório, exibir a mensagem de que já existe no repositório
		if(repositorioGerente.obterGerente(gerente.getStrCpf()) != null) {
			
			strMensagemErro = "CPF já existente.";
			return strMensagemErro;
			
		}
		
		if(gerente.getStrCpf().length() > 11) {
			
			strMensagemErro = "Quantidade de caracteres superior a 11 dígitos.";
			return strMensagemErro;
			
		} 
		
		if(gerente.getStrNome().length() > 10) {
			
			strMensagemErro = "Para o nome do Gerente, máximo de 10 caracteres.";
			return strMensagemErro;
			
		}
		
		if(gerente.getStrRegional().length() > 2) {
			
			strMensagemErro = "Para o nome da Regional, máximo de 2 caracteres.";
			return strMensagemErro;
			
		}
		
		
		
		return strMensagemErro;
	}
	
}
