package br.impacta.telas.controletelas;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JTextField;

import br.impacta.repositorio.RepositorioGerente;
import br.impacta.telas.FormGerente;
import br.impacta.telas.FormGerenteAlterarLista;
import br.impacta.telas.FormGerenteExcluir;
import br.impacta.telas.FormGerenteListar;
import br.impacta.telas.FormGerentesFolha;

public class MenuInicialControle implements ActionListener{

	JTextField opcaoMenuJTextField;
	JFrame frameMenuInicial;
	
	FormGerente formGerente = new FormGerente();
	RepositorioGerente repositorioGerente = new RepositorioGerente();
	
	FormGerenteListar formGerenteListar = new FormGerenteListar();	
	FormGerenteExcluir formGerenteExcluir = new FormGerenteExcluir();	
	FormGerentesFolha formGerenteFolha = new FormGerentesFolha();	
	FormGerenteAlterarLista formGerenteAlterarLista = new FormGerenteAlterarLista();
	
	
	
	//Sobrecarga, mantendo mais de um método, porém, com assinaturas diferentes
	public MenuInicialControle(JTextField opcaoMenuConstrutor, JFrame frameMenuInicialConstrutor) {
		this.opcaoMenuJTextField = opcaoMenuConstrutor;
		this.frameMenuInicial = frameMenuInicialConstrutor;		
	}
	
	public MenuInicialControle() {
		
	}
	
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(opcaoMenuJTextField.getText().equals("1") || opcaoMenuJTextField.getText().equals("2") || opcaoMenuJTextField.getText().equals("3") || opcaoMenuJTextField.getText().equals("4") || opcaoMenuJTextField.getText().equals("5") || opcaoMenuJTextField.getText().equals("6")){
			
			frameMenuInicial.setVisible(false);
			
			switch(opcaoMenuJTextField.getText()) {
			
			case "1":
				formGerente.incluirGerente(opcaoMenuJTextField, frameMenuInicial, repositorioGerente);
				break;
				
			case "2":
				formGerenteListar.listarGerente(repositorioGerente.exibirGerentes(), frameMenuInicial);
				break;

			case "3":
				formGerenteExcluir.excluirGerente(repositorioGerente.exibirGerentes(), frameMenuInicial, repositorioGerente);
				break;
			
			case "4":
				formGerenteFolha.listarFolhaGerente(repositorioGerente.exibirGerentes(), frameMenuInicial);
				break;
				
			case "5":
				formGerenteAlterarLista.listarGerenteAlterar(repositorioGerente.exibirGerentes(), frameMenuInicial, repositorioGerente);
				break;
				
			case "6":
				frameMenuInicial.setVisible(false);
				break;
				
			}
			
		}
		
	}

}
