package br.impacta.telas.controletelas;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import br.impacta.repositorio.RepositorioGerente;

public class FormGerenteExcluirControle implements ActionListener{

	JFrame formGerenteExcluir;
	JFrame telaInicial;
	JTextField txtCpf;
	
	RepositorioGerente repositorioGerente;
	
	boolean validaExclusao = false;
	
	public FormGerenteExcluirControle(JFrame formGerenteExcluirConstrutor, JFrame telaInicialConstrutor, JTextField txtCpfConstrutor, RepositorioGerente repositorioGerenteConstrutor) {
		super();
		this.formGerenteExcluir = formGerenteExcluirConstrutor;
		this.telaInicial = telaInicialConstrutor;
		this.txtCpf = txtCpfConstrutor;
		this.repositorioGerente = repositorioGerenteConstrutor;
		
	}
	
	
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
	
		validaExclusao = repositorioGerente.excluirGerente(txtCpf.getText());
		
		if(validaExclusao) {
			JOptionPane.showMessageDialog(null, "Gerente " + txtCpf.getText() + " excluído com sucesso.");
			telaInicial.setVisible(true);
			formGerenteExcluir.setVisible(false);
		}else {
			JOptionPane.showMessageDialog(null, "Gerente " + txtCpf.getText() + " não encontrado. Favor verificar a ortografia e realizar a exclusão novamente");
		}
	}
	
}
