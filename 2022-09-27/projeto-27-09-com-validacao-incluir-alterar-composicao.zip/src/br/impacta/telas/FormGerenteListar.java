package br.impacta.telas;

import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import br.impacta.model.Gerente;
import br.impacta.telas.controletelas.FormGerenteListarControle;

public class FormGerenteListar {

	
	public void listarGerente(List<Gerente> listaDeGerentes, JFrame telaInicial) {
		
		int vTotalLinhas = listaDeGerentes.size(); //Obter o total de linhas da lista
		
		String [][] gridGerentes = new String [vTotalLinhas][6];
		
		int vPosLin = 0;
		
		//Elaborar o Loop contendo os dados da lista montando conforme Array Bidimensional
		
		for(Gerente gerente: listaDeGerentes) {
			
			gridGerentes[vPosLin][0] = gerente.getStrCpf();
			gridGerentes[vPosLin][1] = gerente.getStrNome();
			gridGerentes[vPosLin][2] = Double.toString(gerente.getDblSalario());
			gridGerentes[vPosLin][3] = gerente.getStrRegional();
			gridGerentes[vPosLin][4] = gerente.getEnderecoGerente().getEndereco();
			gridGerentes[vPosLin][5] = gerente.getEnderecoGerente().getBairro();
		
			
			vPosLin++;
		}
		
		//Criando o título para a gridGerentes
		String nomeColunas[] = {"CPF do Gerente","Nome do Gerente", "Salário do Gerente", "Reginal do Gerente", "Enderço do Gerente", "Bairro do Gerente"};
		
		JFrame formGerenteListar = new JFrame();
		formGerenteListar.setSize(500, 600);
		formGerenteListar.setTitle("Lista dos Gerentes Cadastrados");
		
		JTable tabelaGerentes = new JTable(gridGerentes, nomeColunas);
		tabelaGerentes.setBounds(30, 40, 200, 300);
		
		JScrollPane barraDeRolagem = new JScrollPane(tabelaGerentes);
		JPanel painelGerentes = new JPanel();
		
		painelGerentes.add(barraDeRolagem);

		JButton cmdVoltar = new JButton("Menu");
		painelGerentes.add(cmdVoltar);
		
		
		formGerenteListar.add(painelGerentes);
		formGerenteListar.setVisible(true);
		
		FormGerenteListarControle formGerenteListarC = new FormGerenteListarControle(telaInicial, formGerenteListar);
		
		cmdVoltar.addActionListener(formGerenteListarC);
		
		
	}
	
}
