package br.impacta;

import br.impacta.controlador.ControleDeCadastro;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ControleDeCadastro controleDeCadastro = new ControleDeCadastro();
		controleDeCadastro.iniciarPrograma();
		
		
	}

}
