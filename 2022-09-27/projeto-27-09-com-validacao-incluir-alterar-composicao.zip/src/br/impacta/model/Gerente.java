package br.impacta.model;

public class Gerente {

	private String strCpf;
	private String strNome;
	private Double dblSalario;
	private String strRegional;
	
	EnderecoGerente enderecoGerente;
	
	
	public EnderecoGerente getEnderecoGerente() {
		return enderecoGerente;
	}
	public void setEnderecoGerente(EnderecoGerente enderecoGerente) {
		this.enderecoGerente = enderecoGerente;
	}
	
	public String getStrCpf() {
		return strCpf;
	}
	public void setStrCpf(String strCpf) {
		this.strCpf = strCpf;
	}
	public String getStrNome() {
		return strNome;
	}
	public void setStrNome(String strNome) {
		this.strNome = strNome;
	}
	public Double getDblSalario() {
		return dblSalario;
	}
	public void setDblSalario(Double dblSalario) {
		this.dblSalario = dblSalario;
	}
	public String getStrRegional() {
		return strRegional;
	}
	public void setStrRegional(String strRegional) {
		this.strRegional = strRegional;
	}		
	
	
	
	
	
}
