package br.atos.zoo_animal.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import br.atos.zoo_animal.model.Cuidador;

public interface CuidadorRepository extends CrudRepository<Cuidador, Long> {
		Cuidador findById(long idCuid);
		List<Cuidador> findAll();
		
		@Query(value="SELECT * FROM t_cuid", nativeQuery=true)
		List<Cuidador> exibirCuidadores();
		
		@Query(value= "SELECT max(id_cuid) as 'ultimo_id' FROM t_cuid", nativeQuery=true)
		Long findLastIdCuid();
		
}
