package br.atos.dataBase;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import br.atos.model.LoginEntidade;

public class Dao {

	private String dbUrl = "jdbc:mysql://bepvy7pxasgwnuhjyrwx-mysql.services.clever-cloud.com:3306/bepvy7pxasgwnuhjyrwx?useTimezone=true&serverTimezone=UTC";
	private String dbUser = "ubz49aibqmausmy7";
	private String dbPass = "1gJs0fGHtnKjb0DirEYP";
	private String dbDriver = "com.mysql.cj.jdbc.Driver";
	

	public void carregarDriver(String dbDriver) {
		try {
			Class.forName(dbDriver);
		}catch(Exception e) {
			e.printStackTrace();
			System.out.println("Erro ao carregar o Driver");
		}
		
	}
	
	
	public Connection criarConexao() {
		
		Connection daoCN = null;

		try {
			daoCN = DriverManager.getConnection(dbUrl, dbUser, dbPass);
			
		}catch(Exception e) {
			e.printStackTrace();
			System.out.println("Erro ao conectar a base de dados");
		}
		
		return daoCN;
	}
	
	
	public boolean validaLogin(LoginEntidade loginEntidade) {
		
		boolean validacao = false;
		
		carregarDriver(dbDriver);
		
		Connection daoCN = criarConexao();
		
		String strSQL = "SELECT * FROM tUsuarAcssoSist WHERE iUsuarAcssoSist = ? AND cSenhAcssoSist = ?";
		
		PreparedStatement linhaDeExecucao;
		
		try {
			linhaDeExecucao = daoCN.prepareStatement(strSQL);
			linhaDeExecucao.setString(1, loginEntidade.getUsername());
			linhaDeExecucao.setString(2, loginEntidade.getPassword());
			
			ResultSet daoRS = linhaDeExecucao.executeQuery();
			
			validacao = daoRS.next();
			
		}catch(Exception e) {
			e.printStackTrace();
			System.out.println("Erro ao validar Login");
		}
		
		
		return validacao;
	}
	
	public boolean incluirUsuario(LoginEntidade loginEntidade) {
		
		
		boolean inclusao = false;
		boolean existeUsuario = false;
		
		carregarDriver(dbDriver);
		
		Connection daoCN = criarConexao();
		
		String strSQL = "SELECT * FROM tUsuarAcssoSist WHERE iUsuarAcssoSist = ?";
		
		PreparedStatement linhaDeExecucao;
		
		try {
			linhaDeExecucao = daoCN.prepareStatement(strSQL);
			linhaDeExecucao.setString(1, loginEntidade.getUsername());
			
			ResultSet daoRS = linhaDeExecucao.executeQuery();
			
			existeUsuario = daoRS.next();
			
			if(existeUsuario) {
				//retornar falso
				return inclusao;
			}
			
			strSQL = "INSERT INTO tUsuarAcssoSist(iUsuarAcssoSist, cSenhAcssoSist) VALUES (?,?)";
			
			PreparedStatement linhaDeInclusao;
			
			try {
				linhaDeInclusao = daoCN.prepareStatement(strSQL);
				linhaDeInclusao.setString(1, loginEntidade.getUsername());
				linhaDeInclusao.setString(2, loginEntidade.getPassword());
				
				linhaDeInclusao.execute();
				
				inclusao = true;
				
			}catch(Exception e) {
				e.printStackTrace();
				System.out.println("Erro ao criar Login");				
			}
			
		}catch(Exception e) {
			e.printStackTrace();
			System.out.println("Erro ao validar Login existente");
		}
		
		return inclusao;
	}
}
