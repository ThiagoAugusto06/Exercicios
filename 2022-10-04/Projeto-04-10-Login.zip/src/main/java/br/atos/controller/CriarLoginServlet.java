package br.atos.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.atos.dataBase.Dao;
import br.atos.model.LoginEntidade;

@WebServlet("/CriarLogin")
public class CriarLoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

    public CriarLoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    	Dao loginDao = new Dao();
    	
    	String username = request.getParameter("createusername");
    	String password = request.getParameter("createpassword");
    	String passwordconfirm = request.getParameter("createpasswordconfirm");
    
    	if(!(password.equals(passwordconfirm))) { //Senha e confirmação de senha, não conferem
    		//colocar a página com o botão de voltar
    		response.sendRedirect("loginSenhaNaoConfere.jsp");
    		return;
    	}
    	
    	LoginEntidade loginEntidade = new LoginEntidade();
    	
    	loginEntidade.setUsername(username);
    	loginEntidade.setPassword(password);
		
		if(loginDao.incluirUsuario(loginEntidade)) {
			response.sendRedirect("loginCriadoSucesso.jsp");			
		}else {
			response.sendRedirect("loginNaoCriado.jsp");
		}
		
	}

}
