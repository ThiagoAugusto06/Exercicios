export interface ModelCuidadores {
  idCuid: number;
  iCuid: string;
  nMatrCuid: string;
  editar: number;
  excluir: number;
  addJaula: number;
}
