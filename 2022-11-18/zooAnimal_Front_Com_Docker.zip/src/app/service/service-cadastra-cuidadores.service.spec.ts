import { TestBed } from '@angular/core/testing';

import { ServiceCadastraCuidadoresService } from './service-cadastra-cuidadores.service';

describe('ServiceCadastraCuidadoresService', () => {
  let service: ServiceCadastraCuidadoresService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ServiceCadastraCuidadoresService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
