import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CadastrarCuidadoresComponent } from './cadastrar-cuidadores.component';

describe('CadastrarCuidadoresComponent', () => {
  let component: CadastrarCuidadoresComponent;
  let fixture: ComponentFixture<CadastrarCuidadoresComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CadastrarCuidadoresComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CadastrarCuidadoresComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
