import { ServiceCadastraCuidadoresService } from './../../service/service-cadastra-cuidadores.service';
import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-cadastrar-cuidadores',
  templateUrl: './cadastrar-cuidadores.component.html',
  styleUrls: ['./cadastrar-cuidadores.component.css']
})
export class CadastrarCuidadoresComponent implements OnInit {


  constructor(){}

  ngOnInit(): void {
  }

}
