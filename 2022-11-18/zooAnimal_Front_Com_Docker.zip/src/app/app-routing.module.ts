import { CadastrarCuidadoresComponent } from './view/cadastrar-cuidadores/cadastrar-cuidadores.component';
import { HomeComponent } from './view/home/home.component';
import { NgModule } from '@angular/core';
import { Router, RouterModule, Routes } from '@angular/router';

const routes: Routes = [
{ path: '',  component: HomeComponent },
{ path: 'cadastrarCuidador', component: CadastrarCuidadoresComponent},
//{ path: 'editarCuidador', component: CadastrarCuidadoresComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})


export class AppRoutingModule { }
