package br.atos.zoo_aula.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import br.atos.zoo_aula.model.Cuidador;
import br.atos.zoo_aula.model.Jaula;
import br.atos.zoo_aula.repository.CuidadorRepository;
import br.atos.zoo_aula.repository.JaulaRepository;

@Controller
public class JaulaController {

	@Autowired
	JaulaRepository jaulaRepository;
	
	@Autowired
	CuidadorRepository cuidadorRepository;
	
	@RequestMapping(value = "/manCadJaula", method = RequestMethod.GET)
	public ModelAndView manCadJaula() {
		ModelAndView jaulaModelAndView = new ModelAndView("manCadJaula");
		Iterable<Cuidador> cuidadores = cuidadorRepository.findAll();		
		jaulaModelAndView.addObject("cuidadores", cuidadores);
		return jaulaModelAndView;
	}
	
	
	
	@RequestMapping(value = "/manExEdJaula/{id}", method = RequestMethod.GET) //Método que acionará o editar e exibir os dados antes de "salvar"
	public ModelAndView manExibEditJaula(@PathVariable ("id") long IdCuid) {
		
		Cuidador cuidador = cuidadorRepository.findById(IdCuid);
		ModelAndView cuidadoresModelAndView = new ModelAndView("manEditJaula");
		cuidadoresModelAndView.addObject("cuidador", cuidador);
		
		Iterable<Jaula> jaulas = jaulaRepository.findByCuidadores(cuidador);
		cuidadoresModelAndView.addObject("jaulas", jaulas);
		
		return cuidadoresModelAndView;
	}
	
	
	@RequestMapping(value = "/manExEdJaula/{id}", method = RequestMethod.POST)
	public String manExibEditJaulaSalvar(@PathVariable("id") long idCuid, Jaula jaula) {
		
		Cuidador cuidador = cuidadorRepository.findById(idCuid);
		List<Cuidador> cuidadores = new ArrayList<>();
		cuidadores.add(cuidador);
		
		jaula.setCuidadores(cuidadores);
		jaulaRepository.save(jaula);
		return "redirect:/manExEdJaula/{id}";
		
	}
	
	
}
