package br.atos.zoo_aula;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

@SpringBootApplication
public class ZooAulaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ZooAulaApplication.class, args);
		
		System.out.println(new BCryptPasswordEncoder().encode("lalala"));
	}

}
