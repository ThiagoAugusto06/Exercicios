package br.atos.zoo_aula.repository;

import org.springframework.data.repository.CrudRepository;

import br.atos.zoo_aula.model.Cuidador;

public interface CuidadorRepository extends CrudRepository<Cuidador, Long>{
	Cuidador findById(long idCuid);
	
}
