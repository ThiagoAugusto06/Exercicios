package br.atos.controller;

import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import br.atos.model.Endereco;
import br.atos.model.Estudante;

@ManagedBean(name = "estudanteBean")
@SessionScoped

public class EstudanteMB {

	private List<Estudante> estudantes = new ArrayList<>();
	Estudante estudante = new Estudante();
	Endereco endereco = new Endereco();
	
	
	
	public List<Estudante> getEstudantes() {
		return estudantes;
	}


	public void setEstudantes(List<Estudante> estudantes) {
		this.estudantes = estudantes;
	}


	public Estudante getEstudante() {
		return estudante;
	}


	public void setProfessor(Estudante estudante) {
		this.estudante = estudante;
	}


	public String salvarEstudante() {

		estudante.setEndereco(endereco);
		estudantes.add(estudante);
		
		return "";
	}

	public Endereco getEndereco() {
		return endereco;
	}


	public void setEndereco(Endereco endereco) {
		this.endereco = endereco;
	}
	
	
	
	
}
