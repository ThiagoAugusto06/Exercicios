package br.atos.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import br.atos.model.Endereco;
import br.atos.model.Estudante;

public class Dao {
	
	private String dbUrl = "jdbc:mysql://bepvy7pxasgwnuhjyrwx-mysql.services.clever-cloud.com:3306/bepvy7pxasgwnuhjyrwx?useTimezone=true&serverTimezone=UTC";
	private String dbUser = "ubz49aibqmausmy7";
	private String dbPass = "1gJs0fGHtnKjb0DirEYP";
	private String dbDriver = "com.mysql.cj.jdbc.Driver";
	
	public void carregarDriver(String dbDriver) {
		try {
			Class.forName(dbDriver);
		}catch(Exception e) {
			e.printStackTrace();
			System.out.println("Erro ao carregar o Driver");
		}
	
	}
	
	public Connection criarConexao() {
		
		Connection daoCN = null;

		try {
			daoCN = DriverManager.getConnection(dbUrl, dbUser, dbPass);
			
		}catch(Exception e) {
			e.printStackTrace();
			System.out.println("Erro ao conectar a base de dados na nuvem");
		}
		
		return daoCN;
	}
	
	
	public boolean incluirEstudante(Estudante estudante) {
		
		
		boolean inclusao = false;
		boolean existeCadastro = false;
		
		carregarDriver(dbDriver);
		
		Connection daoCN = criarConexao();
		
		String strSQL = "SELECT * FROM tEstdt WHERE cCpfEstdt = ?";
		
		PreparedStatement linhaDeExecucao;
		
		try {
			linhaDeExecucao = daoCN.prepareStatement(strSQL);
			linhaDeExecucao.setString(1, estudante.getCpf());
			
			ResultSet daoRS = linhaDeExecucao.executeQuery();
			
			existeCadastro = daoRS.next();
			
			if(existeCadastro) {
				//retornar falso
				return inclusao;
			}
			
			strSQL = "INSERT INTO tEstdt (cCpfEstdt, iEstdt, cTurmaEstdt, vMediaEstdt, rEnderRuaEstdt, nCasaEstdt, iCdadeEstdt) VALUES (?,?,?,?,?,?,?)";
			
			PreparedStatement linhaDeInclusao;
			
			try {
				linhaDeInclusao = daoCN.prepareStatement(strSQL);
				linhaDeInclusao.setString(1, estudante.getCpf());
				linhaDeInclusao.setString(2, estudante.getNome());
				linhaDeInclusao.setString(3, estudante.getTurma());
				linhaDeInclusao.setString(4, Double.toString(estudante.getMedia()));
				linhaDeInclusao.setString(5, estudante.getEndereco().getRua());
				linhaDeInclusao.setString(6, estudante.getEndereco().getCasa());
				linhaDeInclusao.setString(7, estudante.getEndereco().getCidade());
				
				linhaDeInclusao.execute();
				
				inclusao = true;
				
			}catch(Exception e) {
				e.printStackTrace();
				System.out.println("Erro ao criar Login");				
			}finally {
				if (linhaDeExecucao != null) {
					linhaDeExecucao.close();
				}				
				if (daoCN != null) {
					daoCN.close();
				}
			}
			
		}catch(Exception e) {
			e.printStackTrace();
			System.out.println("Erro ao validar Login existente");
		}
		
		return inclusao;
	}
	
	
	public boolean alterarEstudante(Estudante estudante) {
		
		
		boolean alteracao = false;
		boolean existeCadastro = false;
		
		carregarDriver(dbDriver);
		
		Connection daoCN = criarConexao();
		
		String strSQL = "SELECT * FROM tEstdt WHERE cCpfEstdt = ?";
		
		PreparedStatement linhaDeExecucao;
		
		try {
			linhaDeExecucao = daoCN.prepareStatement(strSQL);
			linhaDeExecucao.setString(1, estudante.getCpf());
			
			ResultSet daoRS = linhaDeExecucao.executeQuery();
			
			existeCadastro = daoRS.next();
			
			if(!existeCadastro) { //Se não existe o estudante, não podemos realizar a alteração
				//retornar falso
				return alteracao;
			}
			
			strSQL = "UPDATE tEstdt SET iEstdt = ?, cTurmaEstdt = ?, vMediaEstdt = ?, rEnderRuaEstdt = ?, nCasaEstdt = ?, iCdadeEstdt = ? WHERE cCpfEstdt = ?";
			
			PreparedStatement linhaDeInclusao;
			
			try {
				linhaDeInclusao = daoCN.prepareStatement(strSQL);
				linhaDeInclusao.setString(1, estudante.getNome());
				linhaDeInclusao.setString(2, estudante.getTurma());
				linhaDeInclusao.setString(3, Double.toString(estudante.getMedia()));
				linhaDeInclusao.setString(4, estudante.getEndereco().getRua());
				linhaDeInclusao.setString(5, estudante.getEndereco().getCasa());
				linhaDeInclusao.setString(6, estudante.getEndereco().getCidade());
				linhaDeInclusao.setString(7, estudante.getCpf());
				
				linhaDeInclusao.execute();
				
				alteracao = true;
				
			}catch(Exception e) {
				e.printStackTrace();
				System.out.println("Erro ao alterar o estudante");				
			}finally {
				if (linhaDeExecucao != null) {
					linhaDeExecucao.close();
				}				
				if (daoCN != null) {
					daoCN.close();
				}
			}
			
		}catch(Exception e) {
			e.printStackTrace();
			System.out.println("Erro ao validar estudante existente antes da alteração");
		}
		
		return alteracao;
	}	
	
	
	public boolean excluirEstudante(Estudante estudante) {
		
		
		boolean exclusao = false;
		boolean existeCadastro = false;
		
		carregarDriver(dbDriver);
		
		Connection daoCN = criarConexao();
		
		String strSQL = "SELECT * FROM tEstdt WHERE cCpfEstdt = ?";
		
		PreparedStatement linhaDeExecucao;
		
		try {
			linhaDeExecucao = daoCN.prepareStatement(strSQL);
			linhaDeExecucao.setString(1, estudante.getCpf());
			
			ResultSet daoRS = linhaDeExecucao.executeQuery();
			
			existeCadastro = daoRS.next();
			
			if(!existeCadastro) { //Se não existe o estudante, não podemos realizar a alteração
				//retornar falso
				return exclusao;
			}
			
			strSQL = "DELETE FROM tEstdt WHERE cCpfEstdt = ?";
			
			PreparedStatement linhaDeInclusao;
			
			try {
				linhaDeInclusao = daoCN.prepareStatement(strSQL);
				linhaDeInclusao.setString(1, estudante.getCpf());
				
				linhaDeInclusao.execute();
				
				exclusao = true;
				
			}catch(Exception e) {
				e.printStackTrace();
				System.out.println("Erro ao exclusão o estudante");				
			}finally {
				if (linhaDeExecucao != null) {
					linhaDeExecucao.close();
				}				
				if (daoCN != null) {
					daoCN.close();
				}
			}
			
		}catch(Exception e) {
			e.printStackTrace();
			System.out.println("Erro ao validar estudante existente antes da exclusão");
		}
		
		return exclusao;
	}	
	

	public List<Estudante> selectEstudante(){
		
		
		String strSql = "SELECT * FROM tEstdt";
		
		List<Estudante> listaDeEstudantes = new ArrayList<>();
		
		carregarDriver(dbDriver);
		
		Connection daoCN = criarConexao();
		
		PreparedStatement linhaDeExecucao = null;
		ResultSet daoRS = null;
		
		
		try {

			linhaDeExecucao = daoCN.prepareStatement(strSql);
			daoRS = linhaDeExecucao.executeQuery();
			
			//, , , , , , 
			
			while(daoRS.next()) {
				Estudante estudante = new Estudante();
				Endereco endereco = new Endereco();
				
				estudante.setCpf(daoRS.getString("cCpfEstdt"));
				estudante.setNome(daoRS.getString("iEstdt"));
				estudante.setTurma(daoRS.getString("cTurmaEstdt"));
				estudante.setMedia(Double.parseDouble(daoRS.getString("vMediaEstdt")));
				endereco.setRua(daoRS.getString("rEnderRuaEstdt"));
				endereco.setCasa(daoRS.getString("nCasaEstdt"));
				endereco.setCidade(daoRS.getString("iCdadeEstdt"));
				
				
				estudante.setEndereco(endereco);
				
				listaDeEstudantes.add(estudante);
				
			}
			
			
		}catch (Exception e) {
			
			e.printStackTrace();
			System.out.println("Erro ao gerar a lista de estudantes");
		}finally { //Sempre é executado, com ou sem erros, este trecho sempre vai executar
			try {
				if(linhaDeExecucao != null) {
					linhaDeExecucao.close();
				}

				if(daoCN != null) {
					daoCN.close();
				}

			}catch (Exception e2){
				e2.printStackTrace();
				System.out.println("Erro ao realizar o fechamento da conexão com o banco de dados");				
			}
			
		}
		
		
		return listaDeEstudantes;
	}
	
	
	
	
}
