package br.atos.controller;

import javax.faces.bean.ManagedBean;

@ManagedBean(name = "inicio")

public class InicioMB {

	public String cadastrarProfessor() {
		
		return "cadProfessor.xhtml";
	}
	
	
	public String cadastrarEstudante() {

		return "cadEstudante.xhtml";
	}
	
	
	
}
