package br.atos.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import br.atos.model.Endereco;
import br.atos.model.Estudante;
import br.atos.model.Professor;

public class Dao {
	
	private String dbUrl = "jdbc:mysql://bepvy7pxasgwnuhjyrwx-mysql.services.clever-cloud.com:3306/bepvy7pxasgwnuhjyrwx?useTimezone=true&serverTimezone=UTC";
	private String dbUser = "ubz49aibqmausmy7";
	private String dbPass = "1gJs0fGHtnKjb0DirEYP";
	private String dbDriver = "com.mysql.cj.jdbc.Driver";
	
	public void carregarDriver(String dbDriver) {
		try {
			Class.forName(dbDriver);
		}catch(Exception e) {
			e.printStackTrace();
			System.out.println("Erro ao carregar o Driver");
		}
	
	}
	
	public Connection criarConexao() {
		
		Connection daoCN = null;

		try {
			daoCN = DriverManager.getConnection(dbUrl, dbUser, dbPass);
			
		}catch(Exception e) {
			e.printStackTrace();
			System.out.println("Erro ao conectar a base de dados na nuvem");
		}
		
		return daoCN;
	}
	
	
	public boolean incluirEstudante(Estudante estudante) {
		
		
		boolean inclusao = false;
		boolean existeCadastro = false;
		
		carregarDriver(dbDriver);
		
		Connection daoCN = criarConexao();
		
		String strSQL = "SELECT * FROM tEstdt WHERE cCpfEstdt = ?";
		
		PreparedStatement linhaDeExecucao;
		
		try {
			linhaDeExecucao = daoCN.prepareStatement(strSQL);
			linhaDeExecucao.setString(1, estudante.getCpf());
			
			ResultSet daoRS = linhaDeExecucao.executeQuery();
			
			existeCadastro = daoRS.next();
			
			if(existeCadastro) {
				return alterarEstudante(estudante);
			}
			
			strSQL = "INSERT INTO tEstdt (cCpfEstdt, iEstdt, cTurmaEstdt, vMediaEstdt, rEnderRuaEstdt, nCasaEstdt, iCdadeEstdt) VALUES (?,?,?,?,?,?,?)";
			
			PreparedStatement linhaDeInclusao = null;
			
			try {
				linhaDeInclusao = daoCN.prepareStatement(strSQL);
				linhaDeInclusao.setString(1, estudante.getCpf());
				linhaDeInclusao.setString(2, estudante.getNome());
				linhaDeInclusao.setString(3, estudante.getTurma());
				linhaDeInclusao.setString(4, Double.toString(estudante.getMedia()));
				linhaDeInclusao.setString(5, estudante.getEndereco().getRua());
				linhaDeInclusao.setString(6, estudante.getEndereco().getCasa());
				linhaDeInclusao.setString(7, estudante.getEndereco().getCidade());
				
				linhaDeInclusao.execute();
				
				inclusao = true;
				
			}catch(Exception e) {
				e.printStackTrace();
				System.out.println("Erro ao criar Login");				
			}finally {
				if (linhaDeExecucao != null) {
					linhaDeExecucao.close();
				}				
				if (daoCN != null) {
					daoCN.close();
				}
			}
			
		}catch(Exception e) {
			e.printStackTrace();
			System.out.println("Erro ao validar Login existente");
		}
		
		return inclusao;
	}
	
	
	public boolean alterarEstudante(Estudante estudante) {
		
		
		boolean alteracao = false;
		
		carregarDriver(dbDriver);
		
		Connection daoCN = criarConexao();
		
		try {
			
			String strSQL = "UPDATE tEstdt SET iEstdt = ?, cTurmaEstdt = ?, vMediaEstdt = ?, rEnderRuaEstdt = ?, nCasaEstdt = ?, iCdadeEstdt = ? WHERE cCpfEstdt = ?";
			
			PreparedStatement linhaDeAlteracao = null;
			
			try {
				linhaDeAlteracao = daoCN.prepareStatement(strSQL);
				linhaDeAlteracao.setString(1, estudante.getNome());
				linhaDeAlteracao.setString(2, estudante.getTurma());
				linhaDeAlteracao.setString(3, Double.toString(estudante.getMedia()));
				linhaDeAlteracao.setString(4, estudante.getEndereco().getRua());
				linhaDeAlteracao.setString(5, estudante.getEndereco().getCasa());
				linhaDeAlteracao.setString(6, estudante.getEndereco().getCidade());
				linhaDeAlteracao.setString(7, estudante.getCpf());
				
				linhaDeAlteracao.execute();

				alteracao = true;
				
			}catch(Exception e) {
				e.printStackTrace();
				System.out.println("Erro ao alterar o estudante");				
			}finally {
				if (linhaDeAlteracao != null) {
					linhaDeAlteracao.close();
				}				
				if (daoCN != null) {
					daoCN.close();
				}
			}
			
		}catch(Exception e) {
			e.printStackTrace();
			System.out.println("Erro ao validar estudante existente antes da alteração");
		}
		
		return alteracao;
	}	
	
	
	public boolean excluirEstudante(Estudante estudante) {
		
		
		boolean exclusao = false;
		boolean existeCadastro = false;
		
		carregarDriver(dbDriver);
		
		Connection daoCN = criarConexao();
		
		String strSQL = "SELECT * FROM tEstdt WHERE cCpfEstdt = ?";
		
		PreparedStatement linhaDeExecucao;
		
		try {
			linhaDeExecucao = daoCN.prepareStatement(strSQL);
			linhaDeExecucao.setString(1, estudante.getCpf());
			
			ResultSet daoRS = linhaDeExecucao.executeQuery();
			
			existeCadastro = daoRS.next();
			
			if(!existeCadastro) { //Se não existe o estudante, não podemos realizar a alteração
				//retornar falso
				return exclusao;
			}
			
			strSQL = "DELETE FROM tEstdt WHERE cCpfEstdt = ?";
			
			PreparedStatement linhaDeInclusao;
			
			try {
				linhaDeInclusao = daoCN.prepareStatement(strSQL);
				linhaDeInclusao.setString(1, estudante.getCpf());
				
				linhaDeInclusao.execute();
				
				exclusao = true;
				
			}catch(Exception e) {
				e.printStackTrace();
				System.out.println("Erro ao exclusão o estudante");				
			}finally {
				if (linhaDeExecucao != null) {
					linhaDeExecucao.close();
				}				
				if (daoCN != null) {
					daoCN.close();
				}
			}
			
		}catch(Exception e) {
			e.printStackTrace();
			System.out.println("Erro ao validar estudante existente antes da exclusão");
		}
		
		return exclusao;
	}	
	

	public List<Estudante> selectEstudante(){
		
		
		String strSql = "SELECT * FROM tEstdt";
		
		List<Estudante> listaDeEstudantes = new ArrayList<>();
		
		carregarDriver(dbDriver);
		
		Connection daoCN = criarConexao();
		
		PreparedStatement linhaDeExecucao = null;
		ResultSet daoRS = null;
		
		
		try {

			linhaDeExecucao = daoCN.prepareStatement(strSql);
			daoRS = linhaDeExecucao.executeQuery();
			
			//, , , , , , 
			
			while(daoRS.next()) {
				Estudante estudante = new Estudante();
				Endereco endereco = new Endereco();
				
				estudante.setCpf(daoRS.getString("cCpfEstdt"));
				estudante.setNome(daoRS.getString("iEstdt"));
				estudante.setTurma(daoRS.getString("cTurmaEstdt"));
				estudante.setMedia(Double.parseDouble(daoRS.getString("vMediaEstdt")));
				endereco.setRua(daoRS.getString("rEnderRuaEstdt"));
				endereco.setCasa(daoRS.getString("nCasaEstdt"));
				endereco.setCidade(daoRS.getString("iCdadeEstdt"));
				
				
				estudante.setEndereco(endereco);
				
				listaDeEstudantes.add(estudante);
				
			}
			
			
		}catch (Exception e) {
			
			e.printStackTrace();
			System.out.println("Erro ao gerar a lista de estudantes");
		}finally { //Sempre é executado, com ou sem erros, este trecho sempre vai executar
			try {
				if(linhaDeExecucao != null) {
					linhaDeExecucao.close();
				}

				if(daoCN != null) {
					daoCN.close();
				}

			}catch (Exception e2){
				e2.printStackTrace();
				System.out.println("Erro ao realizar o fechamento da conexão com o banco de dados");				
			}
			
		}
		
		
		return listaDeEstudantes;
	}
	
	
	//Professor
	public boolean incluirProfessor(Professor professor) {
		
		
		boolean inclusao = false;
		boolean existeCadastro = false;
		
		carregarDriver(dbDriver);
		
		Connection daoCN = criarConexao();
		
		String strSQL = "SELECT * FROM tProfs WHERE cCpfProfs = ?";
		
		PreparedStatement linhaDeExecucao;
		
		try {
			linhaDeExecucao = daoCN.prepareStatement(strSQL);
			linhaDeExecucao.setString(1, professor.getCpf());
			
			ResultSet daoRS = linhaDeExecucao.executeQuery();
			
			existeCadastro = daoRS.next();
			
			if(existeCadastro) {
				return alterarProfessor(professor);
			}
			
			strSQL = "INSERT INTO tProfs (cCpfProfs, iProfs, cDiscpProfs, vSalProfs, rEnderRuaProfs, nCasaProfs, iCdadeProfs) VALUES (?,?,?,?,?,?,?)";
			
			PreparedStatement linhaDeInclusao = null;
			
			try {
				linhaDeInclusao = daoCN.prepareStatement(strSQL);
				linhaDeInclusao.setString(1, professor.getCpf());
				linhaDeInclusao.setString(2, professor.getNome());
				linhaDeInclusao.setString(3, professor.getDisciplina());
				linhaDeInclusao.setString(4, Double.toString(professor.getSalario()));
				linhaDeInclusao.setString(5, professor.getEndereco().getRua());
				linhaDeInclusao.setString(6, professor.getEndereco().getCasa());
				linhaDeInclusao.setString(7, professor.getEndereco().getCidade());
				
				linhaDeInclusao.execute();
				
				inclusao = true;
				
			}catch(Exception e) {
				e.printStackTrace();
				System.out.println("Erro ao cadastrar o professor");				
			}finally {
				if (linhaDeExecucao != null) {
					linhaDeExecucao.close();
				}				
				if (daoCN != null) {
					daoCN.close();
				}
			}
			
		}catch(Exception e) {
			e.printStackTrace();
			System.out.println("Erro ao validar professor existente");
		}
		
		return inclusao;
	}
	
	public boolean alterarProfessor(Professor professor) {
		
		
		boolean alteracao = false;
		
		carregarDriver(dbDriver);
		
		Connection daoCN = criarConexao();
		
		try {
			
			String strSQL = "UPDATE tProfs SET iProfs = ?, cDiscpProfs = ?, vSalProfs = ?, rEnderRuaProfs = ?, nCasaProfs = ?, iCdadeProfs = ? WHERE cCpfProfs = ?";
			
			PreparedStatement linhaDeAlteracao = null;
			
			try {
				linhaDeAlteracao = daoCN.prepareStatement(strSQL);
				linhaDeAlteracao.setString(1, professor.getNome());
				linhaDeAlteracao.setString(2, professor.getDisciplina());
				linhaDeAlteracao.setString(3, Double.toString(professor.getSalario()));
				linhaDeAlteracao.setString(4, professor.getEndereco().getRua());
				linhaDeAlteracao.setString(5, professor.getEndereco().getCasa());
				linhaDeAlteracao.setString(6, professor.getEndereco().getCidade());
				linhaDeAlteracao.setString(7, professor.getCpf());
				
				linhaDeAlteracao.execute();

				alteracao = true;
				
			}catch(Exception e) {
				e.printStackTrace();
				System.out.println("Erro ao alterar o professor");				
			}finally {
				if (linhaDeAlteracao != null) {
					linhaDeAlteracao.close();
				}				
				if (daoCN != null) {
					daoCN.close();
				}
			}
			
		}catch(Exception e) {
			e.printStackTrace();
			System.out.println("Erro ao validar professor existente antes da alteração");
		}
		
		return alteracao;
	}	
	
	public boolean excluirProfessor(Professor professor) {
		
		
		boolean exclusao = false;
		boolean existeCadastro = false;
		
		carregarDriver(dbDriver);
		
		Connection daoCN = criarConexao();
		
		String strSQL = "SELECT * FROM tProfs WHERE cCpfProfs = ?";
		
		PreparedStatement linhaDeExecucao;
		
		try {
			linhaDeExecucao = daoCN.prepareStatement(strSQL);
			linhaDeExecucao.setString(1, professor.getCpf());
			
			ResultSet daoRS = linhaDeExecucao.executeQuery();
			
			existeCadastro = daoRS.next();
			
			if(!existeCadastro) { //Se não existe o estudante, não podemos realizar a alteração
				//retornar falso
				return exclusao;
			}
			
			strSQL = "DELETE FROM tProfs WHERE cCpfProfs = ?";
			
			PreparedStatement linhaDeInclusao;
			
			try {
				linhaDeInclusao = daoCN.prepareStatement(strSQL);
				linhaDeInclusao.setString(1, professor.getCpf());
				
				linhaDeInclusao.execute();
				
				exclusao = true;
				
			}catch(Exception e) {
				e.printStackTrace();
				System.out.println("Erro ao realizar a exclusão o professor");				
			}finally {
				if (linhaDeExecucao != null) {
					linhaDeExecucao.close();
				}				
				if (daoCN != null) {
					daoCN.close();
				}
			}
			
		}catch(Exception e) {
			e.printStackTrace();
			System.out.println("Erro ao validar professor existente antes da exclusão");
		}
		
		return exclusao;
	}	
	
	public List<Professor> selectProfessor(){
		
		
		String strSql = "SELECT * FROM tProfs";
		
		List<Professor> listaDeProfessores = new ArrayList<>();
		
		carregarDriver(dbDriver);
		
		Connection daoCN = criarConexao();
		
		PreparedStatement linhaDeExecucao = null;
		ResultSet daoRS = null;
		
		
		try {

			linhaDeExecucao = daoCN.prepareStatement(strSql);
			daoRS = linhaDeExecucao.executeQuery();
			
			//, , , , , , 
			
			while(daoRS.next()) {
				Professor professor= new Professor();
				Endereco endereco = new Endereco();
				
				professor.setCpf(daoRS.getString("cCpfProfs"));
				professor.setNome(daoRS.getString("iProfs"));
				professor.setDisciplina(daoRS.getString("cDiscpProfs"));
				professor.setSalario(Double.parseDouble(daoRS.getString("vSalProfs")));;
				endereco.setRua(daoRS.getString("rEnderRuaProfs"));
				endereco.setCasa(daoRS.getString("nCasaProfs"));
				endereco.setCidade(daoRS.getString("iCdadeProfs"));
				
				
				professor.setEndereco(endereco);
				
				listaDeProfessores.add(professor);
				
			}
			
			
		}catch (Exception e) {
			
			e.printStackTrace();
			System.out.println("Erro ao gerar a lista de professores");
		}finally { //Sempre é executado, com ou sem erros, este trecho sempre vai executar
			try {
				if(linhaDeExecucao != null) {
					linhaDeExecucao.close();
				}

				if(daoCN != null) {
					daoCN.close();
				}

			}catch (Exception e2){
				e2.printStackTrace();
				System.out.println("Erro ao realizar o fechamento da conexão com o banco de dados");				
			}
			
		}
		
		
		return listaDeProfessores;
	}
	
	
	
}
