package br.atos.controller;

import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import br.atos.database.Dao;
import br.atos.model.Endereco;
import br.atos.model.Professor;

@ManagedBean(name = "professorBean")
@SessionScoped
public class ProfessorMB {

	private List<Professor> professores = new ArrayList<>();
	Professor professor = new Professor();
	Endereco endereco = new Endereco();
	Dao daoProfessor = new Dao(); 
	
	
	public List<Professor> getProfessores() {
		professores = daoProfessor.selectProfessor();
		
		return professores;
	}


	public void setProfessores(List<Professor> professores) {
		this.professores = professores;
	}


	public Professor getProfessor() {
		return professor;
	}


	public void setProfessor(Professor professor) {
		this.professor = professor;
	}


	public Endereco getEndereco() {
		return endereco;
	}


	public void setEndereco(Endereco endereco) {
		this.endereco = endereco;
	}
	
	

	public String salvarProfessor() {

		Dao daoProfessor = new Dao();
		
		professor.setEndereco(endereco);		
		daoProfessor.incluirProfessor(professor);
		//Após as operações de inclusão ou alteração, zerar o objeto para apagar os campos
		this.professor = new Professor();
		this.endereco = new Endereco();	
		
		return "";
	}

	public String apagarProfessor(Professor professorItem) {

		Dao daoProfessor = new Dao();
		
		daoProfessor.excluirProfessor(professorItem);
		
		
		return "";
	}
	
	public String editarProfessor(Professor professorItem, Endereco enderecoItem) {

		professor = professorItem;
		endereco = enderecoItem;
		
		return "";
	}
	
	
	
	
}
