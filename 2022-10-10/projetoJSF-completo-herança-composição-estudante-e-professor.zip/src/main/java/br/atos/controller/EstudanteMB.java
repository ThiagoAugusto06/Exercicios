package br.atos.controller;

import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import br.atos.database.Dao;
import br.atos.model.Endereco;
import br.atos.model.Estudante;

@ManagedBean(name = "estudanteBean")
@SessionScoped

public class EstudanteMB {

	private List<Estudante> estudantes = new ArrayList<>();
	Estudante estudante = new Estudante();
	Endereco endereco = new Endereco();
	Dao daoEstudante = new Dao();	
	
	
	public List<Estudante> getEstudantes() {

		estudantes = daoEstudante.selectEstudante();
		
		return estudantes;
	}


	public void setEstudantes(List<Estudante> estudantes) {
		this.estudantes = estudantes;
	}


	public Estudante getEstudante() {
		return estudante;
	}


	public void setProfessor(Estudante estudante) {
		this.estudante = estudante;
	}


	public String salvarEstudante() {

		Dao daoEstudante = new Dao();
		
		estudante.setEndereco(endereco);		
		daoEstudante.incluirEstudante(estudante);
		//Após as operações de inclusão ou alteração, zerar o objeto para apagar os campos
		this.estudante = new Estudante();
		this.endereco = new Endereco();	
		
		return "";
	}

	public String apagarEstudante(Estudante estudanteItem) {

		Dao daoEstudante = new Dao();
		
		daoEstudante.excluirEstudante(estudanteItem);
		
		
		return "";
	}
	
	public String editarEstudante(Estudante estudanteItem, Endereco enderecoItem) {

		estudante = estudanteItem;
		endereco = enderecoItem;
		
		return "";
	}
	
	
	public Endereco getEndereco() {
		return endereco;
	}


	public void setEndereco(Endereco endereco) {
		this.endereco = endereco;
	}
	
	
	
	
}
