package br.impacta.repositorio;

import java.util.ArrayList;
import java.util.List;

import br.impacta.model.Gerente;

public class RepositorioGerente implements IntRepositorioGerente{

	List<Gerente> listaDeGerentes = new ArrayList<>();
	
	@Override
	public boolean salvarGerente(Gerente gerente) {
		// TODO Auto-generated method stub
		try {
			listaDeGerentes.add(gerente);
			
		}catch(Exception e){
			System.out.println("Ocorreu um erro ao incluir o Gerente. Erro:" + e );
			return false;
		}
		
		
		return true;
	}

	@Override
	public List<Gerente> exibirGerentes() {
		// TODO Auto-generated method stub
		return listaDeGerentes;
	}

	
	
	
	
}
