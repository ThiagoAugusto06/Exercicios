package br.impacta.telas;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import br.impacta.repositorio.RepositorioGerente;
import br.impacta.telas.controletelas.FormGerenteControle;


public class FormGerente {

	
	public void incluirGerente(JTextField txtOpcao, JFrame telaInicial, RepositorioGerente repositorioGerente) {
		
		String nomeGerente = "Digite o nome do Gerente: ";
		String cpfGerente = "Digite o CPF do Gerente: ";
		String salarioGerente = "Digite o Salario do Gerente: ";
		String regionalGerente = "Digite a Regional do Gerente: ";
		
		//Detalhes do Formulário (Frame)
		JFrame frameFormGerente = new JFrame();
		frameFormGerente.setSize(200, 300);
		frameFormGerente.setTitle("Inclusão de Gerentes - Versão 23-09");
		frameFormGerente.setLocation(300,300);
		
		JPanel molduraGerente = new JPanel();
		
		JLabel lblNome = new JLabel(nomeGerente);
		molduraGerente.add(lblNome);
		
		JTextField txtNome = new JTextField(10);
		molduraGerente.add(txtNome);
		
		JLabel lblCpf = new JLabel(cpfGerente);
		molduraGerente.add(lblCpf);
		
		JTextField txtCpf = new JTextField(10);
		molduraGerente.add(txtCpf);
		
		JLabel lblSalario = new JLabel(salarioGerente);
		molduraGerente.add(lblSalario);
		
		JTextField txtSalario = new JTextField(10);
		molduraGerente.add(txtSalario);

		JLabel lblRegional = new JLabel(regionalGerente);
		molduraGerente.add(lblRegional);
		
		JTextField txtRegional = new JTextField(10);
		molduraGerente.add(txtRegional);
		
		JButton cmdIncluir = new JButton("Incluir");
		molduraGerente.add(cmdIncluir);
		
		
		frameFormGerente.add(molduraGerente);
		
		frameFormGerente.setVisible(true);
		
		FormGerenteControle formGerenteControle = new FormGerenteControle(frameFormGerente, telaInicial, txtCpf, txtNome, txtSalario, txtRegional, repositorioGerente);
		cmdIncluir.addActionListener(formGerenteControle);
		
	}
	
	
}
