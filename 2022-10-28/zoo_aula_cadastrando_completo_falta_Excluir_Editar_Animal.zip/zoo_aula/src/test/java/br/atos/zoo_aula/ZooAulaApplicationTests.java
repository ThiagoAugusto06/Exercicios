package br.atos.zoo_aula;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZooAulaApplicationTests {

	@Test
	void contextLoads() {
	}

}
