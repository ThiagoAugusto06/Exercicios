package br.atos.zoo_aula.repository;

import org.springframework.data.repository.CrudRepository;

import br.atos.zoo_aula.model.Animal;
import br.atos.zoo_aula.model.Jaula;

public interface AnimalRepository extends CrudRepository<Animal, Long> {
	Animal findById(long idAnim);
	Iterable<Animal> findByJaulas(Jaula jaula);
}
