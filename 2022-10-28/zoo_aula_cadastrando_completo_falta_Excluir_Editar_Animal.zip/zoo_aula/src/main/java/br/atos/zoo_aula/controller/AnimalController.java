package br.atos.zoo_aula.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import br.atos.zoo_aula.model.Animal;
import br.atos.zoo_aula.model.Jaula;
import br.atos.zoo_aula.repository.AnimalRepository;
import br.atos.zoo_aula.repository.JaulaRepository;

@Controller
public class AnimalController {

	@Autowired
	JaulaRepository jaulaRepository;
	
	@Autowired
	AnimalRepository animalRepository;
	
	
	@RequestMapping(value = "/manCadAnimal", method = RequestMethod.GET)
	public ModelAndView manCadAnimal() {
		ModelAndView animalModelAndView = new ModelAndView("manCadAnimal");
		Iterable<Jaula> jaulas = jaulaRepository.findAll();		
		animalModelAndView.addObject("jaulas", jaulas);
		return animalModelAndView;
	}
	
	
	
	@RequestMapping(value = "/manExEdAnimal/{id}", method = RequestMethod.GET) //Método que acionará o editar e exibir os dados antes de "salvar"
	public ModelAndView manExibEditAnimal(@PathVariable ("id") long IdJaula) {
		
		Jaula jaula = jaulaRepository.findById(IdJaula);
		ModelAndView animalModelAndView = new ModelAndView("manEditAnimal");
		animalModelAndView.addObject("jaulas", jaula);
		
		Iterable<Animal> animal = animalRepository.findByJaulas(jaula);
		animalModelAndView.addObject("animais", animal);
		
		return animalModelAndView;
	}
	
	
	@RequestMapping(value = "/manExEdAnimal/{id}", method = RequestMethod.POST)
	public String manExibEditAnimalSalvar(@PathVariable("id") long idJaula, Animal animal) {
		
		Jaula jaula = jaulaRepository.findById(idJaula);
		
		animal.setJaulas(jaula);
		animalRepository.save(animal);
		return "redirect:/manExEdAnimal/{id}";
		
	}
	
	
}
