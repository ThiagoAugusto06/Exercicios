package br.atos.zoo_aula.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import br.atos.zoo_aula.model.Cuidador;
import br.atos.zoo_aula.repository.CuidadorRepository;

@Controller
public class CuidadorController {

	@Autowired
	CuidadorRepository cuidadorRepository;
	
	
	@RequestMapping(value = "/manCuidador", method = RequestMethod.GET)
	public String manCuidador() {
		return "manCuidador";
	}
			
	
	@RequestMapping(value = "/manCadCuidador", method = RequestMethod.GET)
	public ModelAndView manCadCuidador() {
		ModelAndView cuidadoresModelAndView = new ModelAndView("manCadCuidador"); 
		Iterable<Cuidador> cuidadores = cuidadorRepository.findAll();
		cuidadoresModelAndView.addObject("cuidadores", cuidadores);
		return cuidadoresModelAndView;
	}
	
	@RequestMapping(value = "/manCadCuidador", method = RequestMethod.POST)
	public String manSalvarCuidador(Cuidador cuidador) {
		cuidadorRepository.save(cuidador);
		return "redirect:/manCadCuidador";
	}
	
	@RequestMapping(value = "/manExEdCuidador/{id}", method = RequestMethod.GET) //Método que acionará o editar e exibir os dados antes de "salvar"
	public ModelAndView manExibEditCuidador(@PathVariable ("id") long IdCuid) {
		
		Cuidador cuidador = cuidadorRepository.findById(IdCuid);
		ModelAndView cuidadoresModelAndView = new ModelAndView("manEditCuidador");
		cuidadoresModelAndView.addObject("cuidador", cuidador);
		
		Iterable<Cuidador> cuidadores = cuidadorRepository.findAll();
		cuidadoresModelAndView.addObject("cuidadores", cuidadores);
		
		return cuidadoresModelAndView;
	}
	
	
	@PostMapping(value = "/manEdCuidador") //Método que acionará o editar e exibir os dados antes de "salvar"
	public String manEditCuidador(Cuidador cuidador) {
		Cuidador cuidadorAlterado = new Cuidador();
		cuidadorAlterado.setiCuid(cuidador.getiCuid());
		cuidadorAlterado.setIdCuid(cuidador.getIdCuid());
		cuidadorAlterado.setnMatrCuid(cuidador.getnMatrCuid());
		cuidadorRepository.save(cuidadorAlterado);
		
		return "redirect:/manCadCuidador";
	}
	
	
	@RequestMapping(value = "/manExcluiCuidador/{id}", method = RequestMethod.GET) //Método que acionará o editar e exibir os dados antes de "salvar"
	public String manExCuidador(@PathVariable ("id") long IdCuid) {
		
		Cuidador cuidador = cuidadorRepository.findById(IdCuid);
		cuidadorRepository.delete(cuidador);
	
		return "redirect:/manCadCuidador";
	}
	
	
	
	
}
