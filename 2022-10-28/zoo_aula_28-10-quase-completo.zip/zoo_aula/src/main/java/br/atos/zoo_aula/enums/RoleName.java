package br.atos.zoo_aula.enums;

//Este enum, armazena quais serão os tipos de perfis utilizado no Spring Security, adaptados em base de dados para acesso no sistema
public enum RoleName {

	ROLE_ADMIN,
	ROLE_USER;
	
}
