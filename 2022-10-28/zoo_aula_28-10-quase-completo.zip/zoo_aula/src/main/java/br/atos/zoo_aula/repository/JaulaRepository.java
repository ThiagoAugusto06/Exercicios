package br.atos.zoo_aula.repository;

import org.springframework.data.repository.CrudRepository;

import br.atos.zoo_aula.model.Cuidador;
import br.atos.zoo_aula.model.Jaula;

public interface JaulaRepository extends CrudRepository<Jaula, Long>{
	Jaula findById(long idJaula);
	Iterable<Jaula> findByCuidadores(Cuidador cuidador);
}
