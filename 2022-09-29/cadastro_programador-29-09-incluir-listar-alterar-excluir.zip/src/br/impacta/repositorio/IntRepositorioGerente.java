package br.impacta.repositorio;

import java.util.List;

import br.impacta.model.Gerente;

public interface IntRepositorioGerente {

	public boolean salvarGerente(Gerente gerente);
	public List<Gerente> exibirGerentes();
	public boolean excluirGerente(String cpf);
	Gerente obterGerente(String cpf);
	boolean alterarGerente(Gerente gerenteNovo);
}
