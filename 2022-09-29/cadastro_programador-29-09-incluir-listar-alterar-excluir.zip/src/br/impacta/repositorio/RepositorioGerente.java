package br.impacta.repositorio;

import java.util.ArrayList;
import java.util.List;

import br.impacta.model.Gerente;
import br.impacta.persistencia.GerenteDao;

public class RepositorioGerente implements IntRepositorioGerente{

	List<Gerente> listaDeGerentes = new ArrayList<>();
	
	GerenteDao gerenteDao = new GerenteDao();
	
	@Override
	public boolean salvarGerente(Gerente gerente) {
		// TODO Auto-generated method stub
		try {
			//listaDeGerentes.add(gerente);
			gerenteDao.incluirRegistroBanco(gerente);
			
			
		}catch(Exception e){
			System.out.println("Ocorreu um erro ao incluir o Gerente. Erro:" + e );
			return false;
		}
		
		
		return true;
	}

	
	public boolean excluirGerente(String cpf) {
		
		//Procurar na lista de gerentes, o CPF pesquisado. Se igual, excluir
		
		return gerenteDao.excluirRegistroBanco(cpf);
		
	}
	
	@Override
	public List<Gerente> exibirGerentes() {
		// TODO Auto-generated method stub
		
		return gerenteDao.selectGerente();
	}

	
	@Override
	public Gerente obterGerente(String cpf) {
		
		for(Gerente gerente: gerenteDao.selectGerente()) {
			if(gerente.getStrCpf().equals(cpf)) {
				return gerente;
			}
			
		}
		
		return null;
	}
	
		
	@Override
	public boolean alterarGerente(Gerente gerenteNovo) {
		
		return gerenteDao.alterarRegistroBanco(gerenteNovo);
	}

}
