package br.impacta.persistencia;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import br.impacta.model.EnderecoGerente;
import br.impacta.model.Gerente;

public class GerenteDao {

	public boolean incluirRegistroBanco(Gerente gerente) throws Exception {
		
		boolean salvou = false;
		
		String strSql = "INSERT INTO tGerLoja(cdCpfGerLoja, iGerLoja, SalGerLoja, rRgnalGerLoja, rEnderGerLoja, iBairoGerLoja) VALUES(?,?,?,?,?,?)";
		
		Connection conexao = null;
		
		PreparedStatement pstm = null; //objeto para a criação da consulta
		
		try {
				conexao = FabricaDeConexao.criarConexaoMySql();
				pstm = (PreparedStatement)conexao.prepareStatement(strSql);
			
				pstm.setString(1, gerente.getStrCpf());
				pstm.setString(2, gerente.getStrNome());
				pstm.setString(3, Double.toString(gerente.getDblSalario()));
				pstm.setString(4, gerente.getStrRegional());
				pstm.setString(5, gerente.getEnderecoGerente().getEndereco());
				pstm.setString(6, gerente.getEnderecoGerente().getBairro());
		
				pstm.execute();
				
				salvou = true;
				
		}catch (Exception e) {
			
			e.printStackTrace();
			System.out.println("Erro ao incluir o Gerente no banco de dados");
		}finally { //Sempre é executado, com ou sem erros, este trecho sempre vai executar
			try {
				if(pstm != null) {
					pstm.close();
				}

				if(conexao != null) {
					conexao.close();
				}

			}catch (Exception e2){
				e2.printStackTrace();
				System.out.println("Erro ao realizar o fechamento da conexão com o banco de dados");				
			}
			
		}
		
		
		return salvou;
		
	}
	
	public List<Gerente> selectGerente(){
		
		
		String strSql = "SELECT * FROM tGerLoja";
		
		List<Gerente> listaDeGerentes = new ArrayList<>();
		
		Connection conexao = null;
		
		PreparedStatement linhaDeExecucao = null;
		ResultSet daoRS = null;
		
		
		try {
			conexao = FabricaDeConexao.criarConexaoMySql();
			linhaDeExecucao = conexao.prepareStatement(strSql);
			daoRS = linhaDeExecucao.executeQuery();
			
			while(daoRS.next()) {
				Gerente gerente = new Gerente();
				EnderecoGerente endereco = new EnderecoGerente();
				
				gerente.setStrNome(daoRS.getString("iGerLoja"));
				gerente.setStrCpf(daoRS.getString("cdCpfGerLoja"));
				gerente.setStrRegional(daoRS.getString("rRgnalGerLoja"));
				gerente.setDblSalario(Double.parseDouble(daoRS.getString("SalGerLoja")));
				
				endereco.setEndereco(daoRS.getString("rEnderGerLoja"));
				endereco.setBairro(daoRS.getString("iBairoGerLoja"));
				
				gerente.setEnderecoGerente(endereco);
				
				listaDeGerentes.add(gerente);
				
			}
			
			
		}catch (Exception e) {
			
			e.printStackTrace();
			System.out.println("Erro ao incluir o Gerente no banco de dados");
		}finally { //Sempre é executado, com ou sem erros, este trecho sempre vai executar
			try {
				if(linhaDeExecucao != null) {
					linhaDeExecucao.close();
				}

				if(conexao != null) {
					conexao.close();
				}

			}catch (Exception e2){
				e2.printStackTrace();
				System.out.println("Erro ao realizar o fechamento da conexão com o banco de dados");				
			}
			
		}
		
		
		return listaDeGerentes;
	}

	
	public boolean excluirRegistroBanco(String cpfGerente) {
		
		boolean excluiu = false;
		
		String strSql = "DELETE FROM tGerLoja WHERE cdCpfGerLoja = ?";
		
		Connection conexao = null;
		
		PreparedStatement pstm = null; //objeto para a criação da consulta
		
		try {
				conexao = FabricaDeConexao.criarConexaoMySql();
				pstm = (PreparedStatement)conexao.prepareStatement(strSql);
			
				pstm.setString(1, cpfGerente);

		
				pstm.execute();
				
				excluiu = true;
				
		}catch (Exception e) {
			
			e.printStackTrace();
			System.out.println("Erro ao excluir o Gerente no banco de dados");
		}finally { //Sempre é executado, com ou sem erros, este trecho sempre vai executar
			try {
				if(pstm != null) {
					pstm.close();
				}

				if(conexao != null) {
					conexao.close();
				}

			}catch (Exception e2){
				e2.printStackTrace();
				System.out.println("Erro ao realizar o fechamento da conexão com o banco de dados");				
			}
			
		}
		
		return excluiu;
		
	}
	
	
	
	public boolean alterarRegistroBanco(Gerente gerente) {
		
		boolean alterou = false;
		
		String strSql = "UPDATE tGerLoja SET iGerLoja = ?, SalGerLoja = ?, rRgnalGerLoja = ?, rEnderGerLoja = ?, iBairoGerLoja = ? WHERE cdCpfGerLoja = ?";
		
		Connection conexao = null;
		
		PreparedStatement pstm = null; //objeto para a criação da consulta
		
		try {
				conexao = FabricaDeConexao.criarConexaoMySql();
				pstm = (PreparedStatement)conexao.prepareStatement(strSql);
			
				//Campo que será utilizado no where
				pstm.setString(6, gerente.getStrCpf());
				
				//Campos que serão atualizados
				pstm.setString(1, gerente.getStrNome());
				pstm.setString(2, Double.toString(gerente.getDblSalario()));
				pstm.setString(3, gerente.getStrRegional());
				pstm.setString(4, gerente.getEnderecoGerente().getEndereco());
				pstm.setString(5, gerente.getEnderecoGerente().getBairro());

		
				pstm.execute();
				
				alterou = true;
				
		}catch (Exception e) {
			
			e.printStackTrace();
			System.out.println("Erro ao alterar o Gerente no banco de dados");
		}finally { //Sempre é executado, com ou sem erros, este trecho sempre vai executar
			try {
				if(pstm != null) {
					pstm.close();
				}

				if(conexao != null) {
					conexao.close();
				}

			}catch (Exception e2){
				e2.printStackTrace();
				System.out.println("Erro ao realizar o fechamento da conexão com o banco de dados");				
			}
			
		}
		
		return alterou;
		
	}

	
	
	
	
	
	
	
}
