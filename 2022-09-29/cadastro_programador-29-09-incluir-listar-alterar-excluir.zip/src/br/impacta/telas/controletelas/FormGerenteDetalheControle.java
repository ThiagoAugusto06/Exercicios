package br.impacta.telas.controletelas;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import br.impacta.model.EnderecoGerente;
import br.impacta.model.Gerente;
import br.impacta.repositorio.RepositorioGerente;
import br.impacta.telas.validacao.ValidaGerente;

public class FormGerenteDetalheControle implements ActionListener{

	JFrame telaInicial;
	JFrame formGerenteDetalhe;	
	JTextField txtNome;
	JTextField txtCpf;
	JTextField txtSalario;
	JTextField txtRegional;
	JTextField txtEndereco;
	JTextField txtBairro;
	
	RepositorioGerente repositorioGerente;
	Gerente gerenteAtual;
	
	boolean validaAlterar = false;
	String strMensagemErro = null;
	
	ValidaGerente validaGerente = new ValidaGerente();
	
	
	public FormGerenteDetalheControle(JFrame telaInicial, JFrame formGerenteDetalhe, JTextField txtNome,
			JTextField txtCpf, JTextField txtSalario, JTextField txtRegional, RepositorioGerente repositorioGerente,
			Gerente gerenteAtual, JTextField txtEndereco, JTextField txtBairro) {
		super();
		this.telaInicial = telaInicial;
		this.formGerenteDetalhe = formGerenteDetalhe;
		this.txtNome = txtNome;
		this.txtCpf = txtCpf;
		this.txtSalario = txtSalario;
		this.txtRegional = txtRegional;
		this.repositorioGerente = repositorioGerente;
		this.gerenteAtual = gerenteAtual;
		this.txtEndereco = txtEndereco;
		this.txtBairro = txtBairro;
	}



	@Override
	public void actionPerformed(ActionEvent e) {

		clicarAlterar();
		telaInicial.setVisible(true);
		formGerenteDetalhe.setVisible(false);
		
	}

	
	private void clicarAlterar() {
		Gerente gerenteNovo = new Gerente();
		
		EnderecoGerente enderecoGerente = new EnderecoGerente();
		
		gerenteNovo.setStrNome(txtNome.getText());
		gerenteNovo.setStrCpf(txtCpf.getText());
		gerenteNovo.setDblSalario(Double.parseDouble(txtSalario.getText()));
		gerenteNovo.setStrRegional(txtRegional.getText());
		
		enderecoGerente.setEndereco(txtEndereco.getText());
		enderecoGerente.setBairro(txtBairro.getText());
		
		gerenteNovo.setEnderecoGerente(enderecoGerente);
		
		strMensagemErro = validaGerente.validarGerente(gerenteNovo, repositorioGerente, "A");
		
		if(strMensagemErro == null) {
			validaAlterar = repositorioGerente.alterarGerente(gerenteNovo);
			
			if(validaAlterar) {
				JOptionPane.showMessageDialog(null,gerenteNovo.getStrCpf() + " alterado com sucesso.");
			}else {
				JOptionPane.showMessageDialog(null,"Erro no processo de alteração. ");
			}
		}
	}
	
}
