/**
 * 
 */
/**
 * @author taao_
 *
 */
module cadastro_programador {
	requires java.desktop;
	requires java.sql;
}