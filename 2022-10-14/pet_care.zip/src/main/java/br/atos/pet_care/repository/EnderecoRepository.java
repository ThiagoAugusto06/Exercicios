package br.atos.pet_care.repository;

import org.springframework.data.repository.CrudRepository;

import br.atos.pet_care.model.Cliente;
import br.atos.pet_care.model.Endereco;

public interface EnderecoRepository extends CrudRepository<Endereco, Long>{

	Iterable<Endereco> findByCliente(Cliente cliente);
	
}
