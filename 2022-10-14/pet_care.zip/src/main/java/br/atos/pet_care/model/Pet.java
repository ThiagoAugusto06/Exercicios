package br.atos.pet_care.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

//Classe que será utilizada para a inclusão na base de dados e que será
//referência dos campos também, no banco de dados

@Entity
@Table(name="tPetClite")
public class Pet implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	
	
	private String iPet;
	private String rEspce;
	private String rRaca;
	private long nIdade;
	
	@ManyToOne
	private Cliente cliente;
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public Cliente getCliente() {
		return cliente;
	}
	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public String getiPet() {
		return iPet;
	}
	public void setiPet(String iPet) {
		this.iPet = iPet;
	}
	public String getrEspce() {
		return rEspce;
	}
	public void setrEspce(String rEspce) {
		this.rEspce = rEspce;
	}
	public String getrRaca() {
		return rRaca;
	}
	public void setrRaca(String rRaca) {
		this.rRaca = rRaca;
	}
	public long getnIdade() {
		return nIdade;
	}
	public void setnIdade(long nIdade) {
		this.nIdade = nIdade;
	}
}
