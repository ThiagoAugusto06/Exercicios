package br.atos.pet_care.repository;

import org.springframework.data.repository.CrudRepository;

import br.atos.pet_care.model.Cliente;

public interface ClienteRepository extends CrudRepository<Cliente, Long>{
	Cliente findById(long id);
	
	
}
