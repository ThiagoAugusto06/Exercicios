package br.atos.pet_care.repository;

import org.springframework.data.repository.CrudRepository;

import br.atos.pet_care.model.Cliente;
import br.atos.pet_care.model.Pet;

public interface PetRepository extends CrudRepository<Pet, Long>{

		Iterable<Pet> findByCliente(Cliente cliente);
}
