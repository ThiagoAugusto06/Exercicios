package br.atos.pet_care.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

//Classe que será utilizada para a inclusão na base de dados e que será
//referência dos campos também, no banco de dados

@Entity //Indica que a tabela será criada com essa estrutura
@Table(name="tClite") //Indica o nome da tabela no banco de dados
public class Cliente implements Serializable{
	
	private static final long serialVersionUID = 1L;
	

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO) //Para as anotações, não utilizar ;
	private long id;
	
	private String iClite;
	private long nIdadeClite;
	private Endereco endereco;
	
	public Endereco getEndereco() {
		return endereco;
	}
	public void setEndereco(Endereco endereco) {
		this.endereco = endereco;
	}
	public String getiClite() {
		return iClite;
	}
	public void setiClite(String iClite) {
		this.iClite = iClite;
	}
	public long getnIdadeClite() {
		return nIdadeClite;
	}
	public void setnIdadeClite(long nIdadeClite) {
		this.nIdadeClite = nIdadeClite;
	}
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
}
