package br.atos.pet_care.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import br.atos.pet_care.model.Cliente;
import br.atos.pet_care.model.Endereco;
import br.atos.pet_care.model.Pet;
import br.atos.pet_care.repository.ClienteRepository;
import br.atos.pet_care.repository.EnderecoRepository;
import br.atos.pet_care.repository.PetRepository;

@Controller
public class ClienteController {

	//Inicializar as chamadas dos repositórios em todos os lugares do projeto
	@Autowired
	ClienteRepository clienteRepository;
	@Autowired
	EnderecoRepository enderecoRepository;
	@Autowired
	PetRepository petRepository;
	
	
	//Acessar a página de cadastro de clientes
	@RequestMapping (value="/cadCliente", method=RequestMethod.GET)
	public String cadCliente() {
		
		return "cadCliente";
	}
	
	//Este método será acionado quando salvar o cliente
	@RequestMapping (value="/cadCliente", method=RequestMethod.POST)
	public String cadCliente(Cliente cliente, Endereco endereco) {
		
		clienteRepository.save(cliente);
		Cliente clienteNovo = clienteRepository.findById(cliente.getId());
		endereco.setCliente(clienteNovo);
		enderecoRepository.save(endereco);
		return "redirect:/listaClientes";
	}
	


	
	
	@RequestMapping(value="/listaClientes") //Nome da "rota" para executar e caso mudar a página, será exibida como "ModelAndView"
	public ModelAndView listaClientes() {
		ModelAndView clientesModelAndView = new ModelAndView("listaClientes"); //Este objeto vai receber o endereço da página HTML para exibir em tela
		Iterable<Cliente> clientes = clienteRepository.findAll(); //Preenche a lista do tipo "Iterable" para exibir na página HTML
		clientesModelAndView.addObject("clientes", clientes);
		return clientesModelAndView;
		
	}
	
	@RequestMapping(value="/index")
	public ModelAndView index() {
		
		ModelAndView indexModelAndView = new ModelAndView("index");
		return indexModelAndView;
	}
	
	
	@RequestMapping(value="/editarCliente/{id}", method=RequestMethod.GET)
	public ModelAndView editarClienteMetodo(@PathVariable ("id") long IdReq) {
		Cliente cliente = clienteRepository.findById(IdReq);
		
		ModelAndView clienteModelandView = new ModelAndView("editarCliente");
		clienteModelandView.addObject("clientes", cliente);

		Iterable<Endereco> enderecos = enderecoRepository.findByCliente(cliente);
		clienteModelandView.addObject("enderecos", enderecos);
		
		Iterable<Pet> pets = petRepository.findByCliente(cliente);
		clienteModelandView.addObject("pets", pets);
		
		return clienteModelandView;	
		
	}
	
	@RequestMapping(value="/salvarPet/{id}", method=RequestMethod.POST)
	public String editarCliente(@PathVariable ("id") long IdReq, Pet pet) {
		
		Cliente cliente = clienteRepository.findById(IdReq);
		pet.setCliente(cliente);
		petRepository.save(pet);
		return "redirect:/editarCliente/{id}";
	}
	
	
	
}