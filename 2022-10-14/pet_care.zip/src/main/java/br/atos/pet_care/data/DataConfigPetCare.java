package br.atos.pet_care.data;
//Classe que será utilizada para realizar a conexão com a base de dados
//após a interação com a controller nas operações de banco de dados

import javax.sql.DataSource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.jpa.JpaVendorAdapter;
import org.springframework.orm.jpa.vendor.Database;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;

@Configuration

public class DataConfigPetCare {


	@Bean
	public DataSource dataSource() {
		//método que será utilizado para "setar" o banco de dados, apenas com os parâmetros do Spring JPA e seu driver
		
		DriverManagerDataSource driveDB = new DriverManagerDataSource();
		
		driveDB.setDriverClassName("com.mysql.cj.jdbc.Driver");
		driveDB.setUrl("jdbc:mysql://bepvy7pxasgwnuhjyrwx-mysql.services.clever-cloud.com:3306/bepvy7pxasgwnuhjyrwx?useTimezone=true&serverTimezone=UTC");
		driveDB.setUsername("ubz49aibqmausmy7");
		driveDB.setPassword("1gJs0fGHtnKjb0DirEYP");
		return driveDB;
	}
	
	@Bean
	public JpaVendorAdapter jpaVendorAdapter() {
		//método utilizado para "setar" quais as opções do JPA que devemos ver durante um debug ou até mesmo durante uma operação
		// e qual será o dialeto que deve utilizar em suas operações de acordo com o SGBD
		
		HibernateJpaVendorAdapter adapterJPA = new HibernateJpaVendorAdapter();
		
		adapterJPA.setDatabase(Database.MYSQL);
		adapterJPA.setShowSql(true);
		adapterJPA.setGenerateDdl(true);
		adapterJPA.setDatabasePlatform("org.hibernate.dialect.MySQL8Dialect");
		adapterJPA.setPrepareConnection(true);
		
		return adapterJPA;
	}

}
