package br.atos.pet_care.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

//Classe que será utilizada para a inclusão na base de dados e que será
//referência dos campos também, no banco de dados
//Adicionadas as referências da classe de pai, pois esta está sendo utilizada como
//composição na classe Cliente
@Entity
@Table(name="tEnderClite")
public class Endereco implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	
	private String iLogdr;
	private String nLogdr;
	private String rCdade;

	@ManyToOne
	private Cliente cliente;
	
	
	public String getiLogdr() {
		return iLogdr;
	}
	public void setiLogdr(String iLogdr) {
		this.iLogdr = iLogdr;
	}
	public String getnLogdr() {
		return nLogdr;
	}
	public Cliente getCliente() {
		return cliente;
	}
	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}
	public void setnLogdr(String nLogdr) {
		this.nLogdr = nLogdr;
	}
	public String getrCdade() {
		return rCdade;
	}
	public void setrCdade(String rCdade) {
		this.rCdade = rCdade;
	}	
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
}
