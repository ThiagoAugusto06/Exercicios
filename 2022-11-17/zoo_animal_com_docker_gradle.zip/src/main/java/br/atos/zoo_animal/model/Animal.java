package br.atos.zoo_animal.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;


@Entity
@Table(name="tAnim")
public class Animal implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long idAnim;
	@OneToOne
	private Jaula jaulas;
		

	private String iAnim;
	private String iEspc;
	private String rRaca;
	private String dNasc;
	

	
	
	public long getIdAnim() {
		return idAnim;
	}

	public void setIdAnim(long idAnim) {
		this.idAnim = idAnim;
	}



	public String getiAnim() {
		return iAnim;
	}

	public void setiAnim(String iAnim) {
		this.iAnim = iAnim;
	}

	public String getiEspc() {
		return iEspc;
	}

	public void setiEspc(String iEspc) {
		this.iEspc = iEspc;
	}

	public String getrRaca() {
		return rRaca;
	}

	public void setrRaca(String rRaca) {
		this.rRaca = rRaca;
	}

	public String getdNasc() {
		return dNasc;
	}

	public void setdNasc(String dNasc) {
		this.dNasc = dNasc;
	}



	public Jaula getJaulas() {
		return jaulas;
	}

	public void setJaulas(Jaula jaulas) {
		this.jaulas = jaulas;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
}
