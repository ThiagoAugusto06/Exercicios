package br.atos.zoo_animal.model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;


@Entity
@Table(name="tCuid")
public class Cuidador implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long idCuid;
	
	public List<Jaula> getJaulas() {
		return jaulas;
	}

	public void setJaulas(List<Jaula> jaulas) {
		this.jaulas = jaulas;
	}
	private String nMatrCuid;
	private String iCuid;
	
	@JsonIgnore  //Quando tem relacionamento e utiliza API retornando JSON, é necessária a utilização desta anotação, senão vira um loop infinito e a requisição não chega
	@ManyToMany(mappedBy="cuidadores")
	private List<Jaula> jaulas;

	public long getIdCuid() {
		return idCuid;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public void setIdCuid(long idCuid) {
		this.idCuid = idCuid;
	}
	public String getnMatrCuid() {
		return nMatrCuid;
	}
	public void setnMatrCuid(String nMatrCuid) {
		this.nMatrCuid = nMatrCuid;
	}
	public String getiCuid() {
		return iCuid;
	}
	public void setiCuid(String iCuid) {
		this.iCuid = iCuid;
	}


	
	
	
}
