package br.impacta.telas.controletelas;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import br.impacta.model.Gerente;
import br.impacta.repositorio.RepositorioGerente;

public class FormGerenteControle implements ActionListener{

	JFrame frameFormGerente;
	JFrame telaInicial;
	
	JTextField txtCpf;
	JTextField txtNome;
	JTextField txtSalario;
	JTextField txtRegional;
	
	RepositorioGerente repositorioGerente;
	
	boolean validarSalvar = false;
	
	//Sobrecarga - Métodos com o mesmo nome, porém, com assinaturas diferentes (Parâmetros)
	public FormGerenteControle(JFrame frameFormGerente, JFrame telaInicial, JTextField txtCpf, JTextField txtNome,	JTextField txtSalario, JTextField txtRegional, RepositorioGerente repositorioGerente) {
		super();
		this.frameFormGerente = frameFormGerente;
		this.telaInicial = telaInicial;
		this.txtCpf = txtCpf;
		this.txtNome = txtNome;
		this.txtSalario = txtSalario;
		this.txtRegional = txtRegional;
		this.repositorioGerente = repositorioGerente;		
		
	}

	public FormGerenteControle() {
		
	}
	
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// Ao clicar no botão, será chamado o método eventoClicarIncluir()
		eventoClicarIncluir();
	}
	
	private void eventoClicarIncluir() {
		
		Gerente gerente = new Gerente();
		
		gerente.setStrNome(txtNome.getText());
		gerente.setStrCpf(txtCpf.getText());
		gerente.setDblSalario(Double.parseDouble(txtSalario.getText()));
		gerente.setStrRegional(txtRegional.getText());
		
		validarSalvar = repositorioGerente.salvarGerente(gerente);
		
		if(validarSalvar) {
			JOptionPane.showMessageDialog(frameFormGerente, gerente.getStrNome() + " incluído com sucesso.");
			telaInicial.setVisible(true);
			frameFormGerente.setVisible(false); 
		}else {
			JOptionPane.showMessageDialog(frameFormGerente, gerente.getStrNome() + " não foi incluído. Verificar parâmetros");
		}
	}
	
	
}
