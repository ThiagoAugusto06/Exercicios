package br.atos.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import br.atos.dataBase.Dao;
import br.atos.model.LoginEntidade;


@WebServlet("/login")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	
    	response.sendRedirect("login.jsp");
    	
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
    	
    	Dao loginDao = new Dao();
    	
    	String username = request.getParameter("username");
    	String password = request.getParameter("password");
    	RequestDispatcher dispatcher = null;
    	HttpSession session = request.getSession();
    	
    	
    	LoginEntidade loginEntidade = new LoginEntidade();
    	
    	loginEntidade.setUsername(username);
    	loginEntidade.setPassword(password);
    	
    	dispatcher = request.getRequestDispatcher("login.jsp");
    	
    	if(loginDao.validaLogin(loginEntidade)) {
    		session.setAttribute("logado", "sim");
    		session.setAttribute("usuario_logado", loginEntidade.getUsername());
    		dispatcher = request.getRequestDispatcher("loginSucesso.jsp");
    	}else {    		
    		dispatcher = request.getRequestDispatcher("loginInvalido.jsp");
    	}
    	
    	dispatcher.forward(request, response);
    
    }
    
    
}
