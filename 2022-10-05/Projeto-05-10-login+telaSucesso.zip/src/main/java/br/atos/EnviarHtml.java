package br.atos;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class EnviarHtml
 */
@WebServlet("/EnviarHtml")
public class EnviarHtml extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EnviarHtml() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		PrintWriter saida = response.getWriter(); //Cria objeto que utiliza o response para enviar várias strings
		saida.println("<!DOCTYPE html>");
		saida.println("<html>");
		saida.println("<head>");
		saida.println("<meta charset=\"ISO-8859-1\">");
		saida.println("<title>Dados do Desenvolvedor</title>");
		saida.println("</head>");

		saida.println("<body>");

		saida.println("<h1>Dados do Analista que quer voar com Java</h1>");
		saida.println("<h2>Nome: Thiago Oliva</h2>");
		saida.println("<h2>Idade: 40 anos</h2>");
		saida.println("<h2>Email Profissional: thiago.oliva@atos.net</h2>");
		saida.println("<h2>Email Pessoal: taao_6@hotmail.com</h2>");
		
		saida.println("<h1>O que esperar daqui 5 anos?</h1>");
		saida.println("<h2>Atuar e desenvolver projetos em Java pela Atos, com o objetivo de angariar conhecimentos de diversos sistemas, bem como, conquistar mais uma 'plataforma' em minha carreira, visto que o Java hoje, é uma tecnologia que está em diversas empresas.</h2>");
		
		saida.println("<h1><marquee bgcolor=yellow> Agora, partiu para o CRUD em JavaWeb </marquee></h1>");
		
		
		saida.println("</body>");
		
		
		saida.println("</html>");
		
	}




}
