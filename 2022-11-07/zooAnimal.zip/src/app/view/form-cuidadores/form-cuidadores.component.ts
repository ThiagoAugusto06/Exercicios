import { ServiceCadastraCuidadoresService } from './../../service/service-cadastra-cuidadores.service';
import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';


@Component({
  selector: 'app-form-cuidadores',
  templateUrl: './form-cuidadores.component.html',
  styleUrls: ['./form-cuidadores.component.css']
})
export class FormCuidadoresComponent implements OnInit{

  formCuidadores: FormGroup = new FormGroup({}); //Criando a variável que será o grupo de controles do formulário

  //No construtor, iniciar as variáveis para utilizar nas funções subsequentes
  constructor(private formBuilder: FormBuilder, private router: Router, private cuidadorService: ServiceCadastraCuidadoresService) {}


  ngOnInit(): void {
    this.formCuidadores = this.formBuilder.group({
      nMatrCuid: ['', [Validators.required]],
      iCuid: ['', [Validators.required]]
    });
  }

  //Esta função realizada a chamada na service, incluindo os valores do formulário dentro dos parâmetros do JSON para que na API, sejam gravados os dados
  adicionarCuidador(): void{
    if(this.formCuidadores.valid) {
      this.cuidadorService.gravaCuidador(this.formCuidadores.value)
      .subscribe(() =>{
        console.warn('Cuidador cadastrado com sucesso. Você será redirecionado para a página principal');
        this.router.navigate(['']);
      })

    }

  }

}
