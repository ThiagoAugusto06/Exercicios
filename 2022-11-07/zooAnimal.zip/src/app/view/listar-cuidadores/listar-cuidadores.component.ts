import { ServiceCadastraCuidadoresService } from './../../service/service-cadastra-cuidadores.service';
import { ServiceListaCuidadoresService } from './../../service/service-lista-cuidadores.service';
import { ModelCuidadores } from './../../model/model-cuidadores';
import { Component, OnInit } from '@angular/core';
import { Observable} from 'rxjs';
import { Router } from '@angular/router';

@Component({
  selector: 'app-listar-cuidadores',
  templateUrl: './listar-cuidadores.component.html',
  styleUrls: ['./listar-cuidadores.component.css']
})
export class ListarCuidadoresComponent implements OnInit {


  cuidadoresArray: Observable<ModelCuidadores[]>;
  headers = ['idCuid', 'nMatrCuid', 'iCuid', 'editar', 'excluir', 'addJaula'];
  listaCuidadores: any[] | undefined;

  constructor(private serviceListaCuidadoresService: ServiceListaCuidadoresService, private serviceCadastra: ServiceCadastraCuidadoresService,  private router: Router ) {
    this.cuidadoresArray = serviceListaCuidadoresService.listarCuidadores();
    this.cuidadoresArray.subscribe( x => this.listaCuidadores = x); //Convertendo um Observable para ArrayList

   }

  ngOnInit(): void {
  }
  editar(idCuid: number){

  }

  excluir(idCuid: number){
    this.serviceCadastra.excluirCuidador(idCuid)
    .subscribe(() =>{
      console.warn('Cuidador excluído com sucesso. Você será redirecionado para a página principal');
      this.router.navigate(['']).then(() => {window.location.reload()});
    })
  }
}
