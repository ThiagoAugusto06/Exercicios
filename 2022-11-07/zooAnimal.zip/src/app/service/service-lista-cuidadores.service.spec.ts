import { TestBed } from '@angular/core/testing';

import { ServiceListaCuidadoresService } from './service-lista-cuidadores.service';

describe('ServiceListaCuidadoresService', () => {
  let service: ServiceListaCuidadoresService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ServiceListaCuidadoresService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
