import { ModelCuidadores } from './../model/model-cuidadores';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { catchError, Observable, observable, throwError } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class ServiceCadastraCuidadoresService {

  private apiURL = "http://localhost:8080/api"

  httpOptions = {headers: new HttpHeaders({'Content-Type': 'application/json'})}

  constructor(private httpClient: HttpClient) { }

  //Estou obtendo todos os cuidadores no .Get
  obtemTodos(): Observable<any> {
    return this.httpClient.get(this.apiURL + '/exibirCuidadores')
    .pipe(catchError(this.chamaErro));
  }

  //Salvando um cuidador no .Post
  gravaCuidador(post: ModelCuidadores): Observable<any>{
    return this.httpClient.post(this.apiURL + '/inserirCuidador', JSON.stringify(post), this.httpOptions)
    .pipe(catchError(this.chamaErro));
  }


  excluirCuidador(idCuid: number): Observable<any>{
    return this.httpClient.delete(this.apiURL + '/excluirCuidador/' + idCuid)
  }



  chamaErro(error:any) {
    let errorMessage = '';
    if(error.error instanceof ErrorEvent) {
      errorMessage = error.error.message;
    } else {
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    return throwError(errorMessage);
 }




}
