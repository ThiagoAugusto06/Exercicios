import { ModelCuidadores } from './../model/model-cuidadores';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ServiceListaCuidadoresService {

  constructor(private httpClient: HttpClient) { }

  private readonly url = 'http://localhost:8080/api/exibirCuidadores';
  listarCuidadores(){
    return this.httpClient.get<ModelCuidadores[]>(this.url) //retorno de um objeto do Tipo Observable (Opção de Manipular os objetos JSON na classe de serviço)
  }

}
