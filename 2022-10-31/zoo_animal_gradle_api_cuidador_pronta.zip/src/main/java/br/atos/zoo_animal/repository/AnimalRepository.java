package br.atos.zoo_animal.repository;

import org.springframework.data.repository.CrudRepository;

import br.atos.zoo_animal.model.Animal;

public interface AnimalRepository extends CrudRepository<Animal, Long>{
	Animal findById(long idAnim);
}
