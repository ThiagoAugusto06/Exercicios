package br.atos.zoo_animal.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.atos.zoo_animal.model.Cuidador;
import br.atos.zoo_animal.repository.CuidadorRepository;

@RestController //Definindo que esta classe será uma REST API
@RequestMapping("/api") //Todas as requests estarão "dentro" desta rota, sequenciados pelas "pastas subsequentes"
@CrossOrigin  //Esta anotação diz que pode ser implementado tanto GET quanto POST ou demais métodos de HTTP
public class CuidadorController {

	@Autowired
	CuidadorRepository cuidadorRepository;
	
	@GetMapping(value="/exibirCuidadores") //Utilizando o método GET para a exibição dos dados para a API
	public List<Cuidador> exibirCuidadores(){
		
		List<Cuidador> cuidadores = cuidadorRepository.exibirCuidadores(); //Realizado cast para a lista, pois por padrão, o findAll retorna um Iterable
		
		return cuidadores;
	}
	//Incluir cuidador através da API
	@PostMapping(value="/inserirCuidador")
	public void inserirCuidador(@RequestBody Cuidador cuidador) {
		cuidadorRepository.save(cuidador);
		
	}
	
	//Procurar cuidador através da API
	@GetMapping(value="/procurarCuidador/{id}")
	public Cuidador procurarCuidador(@PathVariable long id) {
		Cuidador cuidador = cuidadorRepository.findById(id);
		return cuidador;
	}
	
	//Excluir cuidador através da API
	@DeleteMapping(value="/excluirCuidador/{id}")
	public void excluirCuidador(@PathVariable long id) {
		cuidadorRepository.deleteById(id);
		
	}
	
	//Editar cuidador através da API
	@PutMapping(value="/editarCuidador")
	public void editarCuidador(@RequestBody Cuidador cuidador) {
		cuidadorRepository.save(cuidador);
	}
}
