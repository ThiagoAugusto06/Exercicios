package br.atos.zoo_animal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ZooAnimalApplication {

	public static void main(String[] args) {
		SpringApplication.run(ZooAnimalApplication.class, args);
	}

}
