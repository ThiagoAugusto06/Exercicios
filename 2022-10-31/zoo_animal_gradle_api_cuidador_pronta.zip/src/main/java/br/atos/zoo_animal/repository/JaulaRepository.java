package br.atos.zoo_animal.repository;

import org.springframework.data.repository.CrudRepository;

import br.atos.zoo_animal.model.Jaula;

public interface JaulaRepository extends CrudRepository<Jaula, Long>{
	Jaula findById(long idJaula);
}
