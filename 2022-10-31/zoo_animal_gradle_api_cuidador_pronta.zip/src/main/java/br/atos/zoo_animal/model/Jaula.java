package br.atos.zoo_animal.model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "tJaula")
public class Jaula implements Serializable {
	
	public List<Cuidador> getCuidadores() {
		return cuidadores;
	}

	public void setCuidadores(List<Cuidador> cuidadores) {
		this.cuidadores = cuidadores;
	}

	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long idJaula;
	private String iZoo;
	private String rBloco;
	private String nJaula;
	
	@ManyToMany
	private List<Cuidador> cuidadores;
	
	@OneToOne
	private Animal animais;
	
	public long getIdJaula() {
		return idJaula;
	}


	public Animal getAnimais() {
		return animais;
	}

	public void setAnimais(Animal animais) {
		this.animais = animais;
	}

	public void setIdJaula(long idJaula) {
		this.idJaula = idJaula;
	}

	public String getiZoo() {
		return iZoo;
	}

	public void setiZoo(String iZoo) {
		this.iZoo = iZoo;
	}

	public String getrBloco() {
		return rBloco;
	}

	public void setrBloco(String rBloco) {
		this.rBloco = rBloco;
	}

	public String getnJaula() {
		return nJaula;
	}

	public void setnJaula(String nJaula) {
		this.nJaula = nJaula;
	}


	public static long getSerialversionuid() {
		return serialVersionUID;
	}


	
}
