package br.atos.zoo_animal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZooAnimalApplicationTests {

	@Test
	void contextLoads() {
	}

}
